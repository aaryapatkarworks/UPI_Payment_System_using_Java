@echo off
echo Starting Smart UPI System...
echo.
cd /d "%~dp0"
mvn javafx:run
pause
