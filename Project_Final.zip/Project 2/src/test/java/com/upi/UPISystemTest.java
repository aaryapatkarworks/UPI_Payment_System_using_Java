package com.upi;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class UPISystemTest {

    @Test
    public void testMainClassExists() {
        // Test that the Main class can be instantiated
        assertDoesNotThrow(() -> {
            Main main = new Main();
            assertNotNull(main);
        });
    }

    @Test
    public void testDashboardClassExists() {
        // Test that the Dashboard class can be instantiated
        assertDoesNotThrow(() -> {
            // We can't easily test the Dashboard without a Stage, 
            // but we can verify the class exists
            Class<?> dashboardClass = Class.forName("com.upi.Dashboard");
            assertNotNull(dashboardClass);
        });
    }

    @Test
    public void testRegistrationScreenClassExists() {
        // Test that the RegistrationScreen class can be instantiated
        assertDoesNotThrow(() -> {
            Class<?> registrationClass = Class.forName("com.upi.RegistrationScreen");
            assertNotNull(registrationClass);
        });
    }

    @Test
    public void testSendMoneyScreenClassExists() {
        // Test that the SendMoneyScreen class can be instantiated
        assertDoesNotThrow(() -> {
            Class<?> sendMoneyClass = Class.forName("com.upi.SendMoneyScreen");
            assertNotNull(sendMoneyClass);
        });
    }

    @Test
    public void testReceiveMoneyScreenClassExists() {
        // Test that the ReceiveMoneyScreen class can be instantiated
        assertDoesNotThrow(() -> {
            Class<?> receiveMoneyClass = Class.forName("com.upi.ReceiveMoneyScreen");
            assertNotNull(receiveMoneyClass);
        });
    }

    @Test
    public void testTransactionHistoryClassExists() {
        // Test that the TransactionHistory class can be instantiated
        assertDoesNotThrow(() -> {
            Class<?> historyClass = Class.forName("com.upi.TransactionHistory");
            assertNotNull(historyClass);
        });
    }

    @Test
    public void testTransactionInnerClass() {
        // Test that the Transaction inner class exists and can be instantiated
        assertDoesNotThrow(() -> {
            Class<?> transactionClass = Class.forName("com.upi.TransactionHistory$Transaction");
            assertNotNull(transactionClass);
        });
    }
}
