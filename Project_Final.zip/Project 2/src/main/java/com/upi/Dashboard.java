package com.upi;

import com.upi.service.UserService;
import com.upi.service.PaymentService;
import com.upi.service.MonitoringService;
import com.upi.model.User;
import com.upi.model.Transaction;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.util.List;

public class Dashboard {
    private Stage primaryStage;
    private String userId;
    private UserService userService;
    private PaymentService paymentService;
    private MonitoringService monitoringService;
    private User currentUser;

    public Dashboard(Stage primaryStage, String userId) {
        this.primaryStage = primaryStage;
        this.userId = userId;
        this.userService = UserService.getInstance();
        this.paymentService = PaymentService.getInstance();
        this.monitoringService = MonitoringService.getInstance();
        this.currentUser = userService.findUserByUpiId(userId).orElse(null);
        
        // Update last login
        if (currentUser != null) {
            userService.updateUserLastLogin(userId);
        }
    }

    public void show() {
        BorderPane root = new BorderPane();
        root.setStyle("-fx-background-color: #f5f5f5;");

        // Header
        VBox header = createHeader();
        root.setTop(header);

        // Main content
        VBox mainContent = createMainContent();
        root.setCenter(mainContent);

        // Footer
        HBox footer = createFooter();
        root.setBottom(footer);

        Scene scene = new Scene(root, 800, 600);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Smart UPI System - Dashboard");
    }

    private VBox createHeader() {
        VBox header = new VBox(10);
        header.setStyle("-fx-background-color: #2196F3; -fx-padding: 15;");
        header.setAlignment(Pos.CENTER);

        Text title = new Text("Smart UPI System");
        title.setFont(Font.font("Arial", FontWeight.BOLD, 24));
        title.setFill(Color.WHITE);

        Text welcomeText = new Text("Welcome, " + userId);
        welcomeText.setFont(Font.font("Arial", FontWeight.NORMAL, 16));
        welcomeText.setFill(Color.WHITE);

        header.getChildren().addAll(title, welcomeText);
        return header;
    }

    private VBox createMainContent() {
        VBox mainContent = new VBox(20);
        mainContent.setPadding(new Insets(20));
        mainContent.setAlignment(Pos.TOP_CENTER);

        // Balance Display
        VBox balanceBox = createBalanceDisplay();
        mainContent.getChildren().add(balanceBox);

        // Quick Actions
        HBox quickActions = createQuickActions();
        mainContent.getChildren().add(quickActions);

        // Transaction Section
        VBox transactionSection = createTransactionSection();
        mainContent.getChildren().add(transactionSection);

        return mainContent;
    }

    private VBox createBalanceDisplay() {
        VBox balanceBox = new VBox(10);
        balanceBox.setStyle("-fx-background-color: white; -fx-padding: 20; -fx-border-radius: 10; -fx-background-radius: 10;");
        balanceBox.setAlignment(Pos.CENTER);

        Text balanceLabel = new Text("Available Balance");
        balanceLabel.setFont(Font.font("Arial", FontWeight.NORMAL, 14));

        double currentBalance = currentUser != null ? currentUser.getBalance() : 0.0;
        Text balanceAmount = new Text("₹" + String.format("%.2f", currentBalance));
        balanceAmount.setFont(Font.font("Arial", FontWeight.BOLD, 28));
        balanceAmount.setFill(Color.GREEN);

        // Add user info
        Text userInfo = new Text("Account: " + userId);
        userInfo.setFont(Font.font("Arial", FontWeight.NORMAL, 12));
        userInfo.setFill(Color.DARKBLUE);

        balanceBox.getChildren().addAll(balanceLabel, balanceAmount, userInfo);
        return balanceBox;
    }

    private HBox createQuickActions() {
        HBox quickActions = new HBox(20);
        quickActions.setAlignment(Pos.CENTER);

        Button sendMoneyBtn = createActionButton("Send Money", "#4CAF50");
        Button receiveMoneyBtn = createActionButton("Receive Money", "#FF9800");
        Button scanQRBtn = createActionButton("Scan QR", "#9C27B0");
        Button historyBtn = createActionButton("History", "#2196F3");
        Button profileBtn = createActionButton("Profile", "#795548");
        Button monitoringBtn = createActionButton("Monitoring", "#FF5722");
        Button walletBtn = createActionButton("💳 Wallet", "#673AB7");

        sendMoneyBtn.setOnAction(e -> openSendMoneyScreen());
        receiveMoneyBtn.setOnAction(e -> openReceiveMoneyScreen());
        scanQRBtn.setOnAction(e -> showQRScanner());
        historyBtn.setOnAction(e -> showTransactionHistory());
        profileBtn.setOnAction(e -> openProfileScreen());
        monitoringBtn.setOnAction(e -> openMonitoringDashboard());
        walletBtn.setOnAction(e -> openWalletScreen());

        quickActions.getChildren().addAll(sendMoneyBtn, receiveMoneyBtn, scanQRBtn, historyBtn, profileBtn, monitoringBtn, walletBtn);
        return quickActions;
    }

    private Button createActionButton(String text, String color) {
        Button button = new Button(text);
        button.setStyle("-fx-background-color: " + color + "; -fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 10 20; -fx-border-radius: 5; -fx-background-radius: 5;");
        button.setPrefWidth(120);
        button.setPrefHeight(50);
        return button;
    }

    private VBox createTransactionSection() {
        VBox transactionSection = new VBox(10);
        transactionSection.setStyle("-fx-background-color: white; -fx-padding: 20; -fx-border-radius: 10; -fx-background-radius: 10;");

        Text sectionTitle = new Text("Recent Transactions");
        sectionTitle.setFont(Font.font("Arial", FontWeight.BOLD, 16));

        ListView<String> transactionList = new ListView<>();
        transactionList.setPrefHeight(150);
        
        // Get real transactions from service
        List<Transaction> transactions = paymentService.getTransactionHistory(userId);
        for (Transaction transaction : transactions) {
            String displayText;
            // Determine transaction type based on user's perspective
            if (transaction.getFromUpiId().equals(userId)) {
                // User is the sender
                displayText = String.format("SENT %s to %s - %s", 
                    transaction.getFormattedAmount(),
                    transaction.getToUpiId(),
                    transaction.getRemark());
            } else {
                // User is the receiver
                displayText = String.format("RECEIVED %s from %s - %s", 
                    transaction.getFormattedAmount(),
                    transaction.getFromUpiId(),
                    transaction.getRemark());
            }
            transactionList.getItems().add(displayText);
        }

        transactionSection.getChildren().addAll(sectionTitle, transactionList);
        return transactionSection;
    }

    private HBox createFooter() {
        HBox footer = new HBox(20);
        footer.setStyle("-fx-background-color: #333; -fx-padding: 10;");
        footer.setAlignment(Pos.CENTER);

        Button logoutBtn = new Button("Logout");
        logoutBtn.setStyle("-fx-background-color: #f44336; -fx-text-fill: white; -fx-padding: 8 16;");
        
        logoutBtn.setOnAction(e -> {
            // Return to login screen
            new Main().start(primaryStage);
        });

        footer.getChildren().add(logoutBtn);
        return footer;
    }

    private void openSendMoneyScreen() {
        SendMoneyScreen sendMoney = new SendMoneyScreen(primaryStage, userId, currentUser.getBalance());
        sendMoney.show();
    }

    private void openReceiveMoneyScreen() {
        ReceiveMoneyScreen receiveMoney = new ReceiveMoneyScreen(primaryStage, userId);
        receiveMoney.show();
    }

    private void showQRScanner() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("QR Scanner");
        alert.setHeaderText("QR Code Scanner");
        alert.setContentText("QR Code scanning feature would be implemented here.\nFor demo: This would open camera to scan QR codes.");
        alert.showAndWait();
    }

    private void showTransactionHistory() {
        TransactionHistory history = new TransactionHistory(primaryStage, userId);
        history.show();
    }
    
    private void openProfileScreen() {
        try {
            UserService userService = UserService.getInstance();
            User currentUser = userService.findUserByUpiId(userId).orElse(null);
            if (currentUser != null) {
                ProfileScreen profile = new ProfileScreen(primaryStage, currentUser);
                profile.show();
            }
        } catch (Exception e) {
            System.err.println("Error opening profile: " + e.getMessage());
        }
    }
    
    private void openMonitoringDashboard() {
        MonitoringDashboard monitoring = new MonitoringDashboard(primaryStage, userId);
        monitoring.show();
    }
    
    private void openWalletScreen() {
        WalletScreen wallet = new WalletScreen(primaryStage, userId);
        wallet.show();
    }
}
