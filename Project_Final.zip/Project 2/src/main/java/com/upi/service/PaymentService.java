package com.upi.service;

import com.upi.database.TransactionRepository;
import com.upi.model.Transaction;
import com.upi.model.User;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public class PaymentService {
    private static PaymentService instance;
    private TransactionRepository transactionRepository;
    private UserService userService;
    
    private PaymentService() {
        this.transactionRepository = new TransactionRepository();
        this.userService = UserService.getInstance();
        initializeDemoTransactions();
    }
    
    public static PaymentService getInstance() {
        if (instance == null) {
            instance = new PaymentService();
        }
        return instance;
    }

    public Transaction sendMoney(String fromUpiId, String toUpiId, double amount, String remark) {
        try {
            // Validate users
            Optional<User> fromUserOpt = userService.findUserByUpiId(fromUpiId);
            Optional<User> toUserOpt = userService.findUserByUpiId(toUpiId);
            
            if (!fromUserOpt.isPresent() || !toUserOpt.isPresent()) {
                System.err.println("Invalid users in transaction: " + fromUpiId + " -> " + toUpiId);
                return createFailedTransaction(fromUpiId, toUpiId, amount, "Invalid user");
            }
            
            User fromUser = fromUserOpt.get();
            User toUser = toUserOpt.get();
            
            // Check balance
            if (fromUser.getBalance() < amount) {
                System.err.println("Insufficient balance for " + fromUpiId + ": has " + fromUser.getBalance() + ", needs " + amount);
                return createFailedTransaction(fromUpiId, toUpiId, amount, "Insufficient balance");
            }
            
            // Create transaction
            Transaction transaction = new Transaction(fromUpiId, toUpiId, amount, "SENT", remark);
            transaction.setTransactionId(UUID.randomUUID().toString());
            transaction.setStatus("COMPLETED");
            
            // Save transaction to database
            transactionRepository.save(transaction);
            
            // Update balances
            userService.updateBalance(fromUpiId, fromUser.getBalance() - amount);
            userService.updateBalance(toUpiId, toUser.getBalance() + amount);
            
            System.out.println("Payment successful: " + fromUpiId + " -> " + toUpiId + ", amount: " + amount);
            return transaction;
            
        } catch (Exception e) {
            System.err.println("Payment failed: " + fromUpiId + " -> " + toUpiId + ", amount: " + amount);
            e.printStackTrace();
            return createFailedTransaction(fromUpiId, toUpiId, amount, "System error");
        }
    }

    public List<Transaction> getTransactionHistory(String upiId) {
        try {
            return transactionRepository.findByUserUpiId(upiId);
        } catch (Exception e) {
            System.err.println("Failed to get transaction history for: " + upiId);
            e.printStackTrace();
            return List.of();
        }
    }

    public Optional<Transaction> getTransactionById(String transactionId) {
        try {
            return transactionRepository.findById(transactionId);
        } catch (Exception e) {
            System.err.println("Failed to get transaction: " + transactionId);
            e.printStackTrace();
            return Optional.empty();
        }
    }

    private Transaction createFailedTransaction(String fromUpiId, String toUpiId, double amount, String reason) {
        Transaction transaction = new Transaction(fromUpiId, toUpiId, amount, "FAILED", reason);
        transaction.setTransactionId(UUID.randomUUID().toString());
        transaction.setStatus("FAILED");
        transactionRepository.save(transaction);
        return transaction;
    }

    private void initializeDemoTransactions() {
        try {
            transactionRepository.initializeDemoTransactions();
            System.out.println("Demo transactions initialized from database");
        } catch (Exception e) {
            System.err.println("Failed to initialize demo transactions");
            e.printStackTrace();
        }
    }

    // Database statistics
    public long getTotalTransactions() {
        try {
            return transactionRepository.getTotalTransactionsCount();
        } catch (Exception e) {
            System.err.println("Failed to get total transactions count");
            e.printStackTrace();
            return 0;
        }
    }

    public double getTotalTransactionAmount() {
        try {
            return transactionRepository.getTotalTransactionAmount();
        } catch (Exception e) {
            System.err.println("Failed to get total transaction amount");
            e.printStackTrace();
            return 0.0;
        }
    }

    public long getSuccessfulTransactions() {
        try {
            return transactionRepository.getSuccessfulTransactionsCount();
        } catch (Exception e) {
            System.err.println("Failed to get successful transactions count");
            e.printStackTrace();
            return 0;
        }
    }

    public String getPaymentStats() {
        long total = getTotalTransactions();
        long successful = getSuccessfulTransactions();
        double totalAmount = getTotalTransactionAmount();
        
        return String.format("Total: %d, Success: %d, Amount: ₹%.2f", 
                           total, successful, totalAmount);
    }
}
