package com.upi.service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

public class MonitoringService {
    private static MonitoringService instance;
    private Map<String, SystemMetrics> systemMetrics;
    private List<PerformanceLog> performanceLogs;
    private AtomicLong totalTransactions;
    private AtomicLong successfulTransactions;
    private AtomicLong failedTransactions;
    private LocalDateTime systemStartTime;
    
    private MonitoringService() {
        this.systemMetrics = new ConcurrentHashMap<>();
        this.performanceLogs = new ArrayList<>();
        this.totalTransactions = new AtomicLong(0);
        this.successfulTransactions = new AtomicLong(0);
        this.failedTransactions = new AtomicLong(0);
        this.systemStartTime = LocalDateTime.now();
        initializeMetrics();
    }
    
    public static MonitoringService getInstance() {
        if (instance == null) {
            instance = new MonitoringService();
        }
        return instance;
    }
    
    private void initializeMetrics() {
        systemMetrics.put("CPU_USAGE", new SystemMetrics("CPU Usage", 0.0, "%"));
        systemMetrics.put("MEMORY_USAGE", new SystemMetrics("Memory Usage", 0.0, "%"));
        systemMetrics.put("ACTIVE_USERS", new SystemMetrics("Active Users", 0.0, "count"));
        systemMetrics.put("TRANSACTION_RATE", new SystemMetrics("Transaction Rate", 0.0, "txn/sec"));
        systemMetrics.put("RESPONSE_TIME", new SystemMetrics("Response Time", 0.0, "ms"));
    }
    
    public void recordTransaction(boolean success) {
        totalTransactions.incrementAndGet();
        if (success) {
            successfulTransactions.incrementAndGet();
        } else {
            failedTransactions.incrementAndGet();
        }
        updateTransactionRate();
    }
    
    public void recordPerformanceLog(String operation, long responseTime, boolean success) {
        PerformanceLog log = new PerformanceLog(operation, responseTime, success);
        performanceLogs.add(log);
        
        // Update average response time
        updateAverageResponseTime();
        
        // Keep only last 100 logs
        if (performanceLogs.size() > 100) {
            performanceLogs.remove(0);
        }
    }
    
    public void updateMetric(String metricName, double value) {
        if (systemMetrics.containsKey(metricName)) {
            SystemMetrics metric = systemMetrics.get(metricName);
            metric.setValue(value);
            metric.setLastUpdated(LocalDateTime.now());
            systemMetrics.put(metricName, metric);
        }
    }
    
    private void updateTransactionRate() {
        // Calculate transactions per second (simplified)
        double rate = totalTransactions.get() / (double) getSystemUptimeSeconds();
        updateMetric("TRANSACTION_RATE", rate);
    }
    
    private void updateAverageResponseTime() {
        if (performanceLogs.isEmpty()) {
            updateMetric("RESPONSE_TIME", 0.0);
            return;
        }
        
        double avgTime = performanceLogs.stream()
                .mapToLong(PerformanceLog::getResponseTime)
                .average()
                .orElse(0.0);
        
        updateMetric("RESPONSE_TIME", avgTime);
    }
    
    public SystemAnalytics getSystemAnalytics() {
        Map<String, Object> analytics = new HashMap<>();
        
        // Basic metrics
        analytics.put("Total Transactions", totalTransactions.get());
        analytics.put("Successful Transactions", successfulTransactions.get());
        analytics.put("Failed Transactions", failedTransactions.get());
        analytics.put("Success Rate", calculateSuccessRate());
        analytics.put("System Uptime", getSystemUptime());
        analytics.put("Active Users", UserService.getInstance().getTotalUsers());
        
        // Performance metrics
        analytics.put("Average Response Time", getAverageResponseTime());
        analytics.put("Transaction Rate", getTransactionRate());
        
        // System health
        analytics.put("System Health", getSystemHealth());
        
        return new SystemAnalytics(analytics, LocalDateTime.now());
    }
    
    public List<PerformanceLog> getRecentPerformanceLogs(int limit) {
        int size = performanceLogs.size();
        if (size <= limit) {
            return new ArrayList<>(performanceLogs);
        } else {
            return performanceLogs.subList(size - limit, size);
        }
    }
    
    public Map<String, SystemMetrics> getCurrentMetrics() {
        // Simulate real-time metrics
        updateMetric("CPU_USAGE", Math.random() * 100);
        updateMetric("MEMORY_USAGE", Math.random() * 100);
        updateMetric("ACTIVE_USERS", UserService.getInstance().getTotalUsers());
        
        return new HashMap<>(systemMetrics);
    }
    
    private double calculateSuccessRate() {
        long total = totalTransactions.get();
        if (total == 0) return 100.0;
        return (successfulTransactions.get() * 100.0) / total;
    }
    
    private String getSystemUptime() {
        long seconds = getSystemUptimeSeconds();
        long hours = seconds / 3600;
        long minutes = (seconds % 3600) / 60;
        return String.format("%d hours %d minutes", hours, minutes);
    }
    
    private long getSystemUptimeSeconds() {
        return java.time.Duration.between(systemStartTime, LocalDateTime.now()).getSeconds();
    }
    
    private double getAverageResponseTime() {
        return performanceLogs.stream()
                .mapToLong(PerformanceLog::getResponseTime)
                .average()
                .orElse(0.0);
    }
    
    private double getTransactionRate() {
        return systemMetrics.get("TRANSACTION_RATE").getValue();
    }
    
    private String getSystemHealth() {
        double cpuUsage = systemMetrics.get("CPU_USAGE").getValue();
        double memoryUsage = systemMetrics.get("MEMORY_USAGE").getValue();
        double successRate = calculateSuccessRate();
        
        if (cpuUsage > 90 || memoryUsage > 90 || successRate < 95) {
            return "CRITICAL";
        } else if (cpuUsage > 70 || memoryUsage > 70 || successRate < 98) {
            return "WARNING";
        } else {
            return "HEALTHY";
        }
    }
    
    public void generateReport() {
        SystemAnalytics analytics = getSystemAnalytics();
        System.out.println("=== SYSTEM PERFORMANCE REPORT ===");
        System.out.println("Generated at: " + analytics.getTimestamp().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
        System.out.println("System Uptime: " + analytics.getMetrics().get("System Uptime"));
        System.out.println("Total Transactions: " + analytics.getMetrics().get("Total Transactions"));
        System.out.println("Success Rate: " + String.format("%.2f%%", (Double) analytics.getMetrics().get("Success Rate")));
        System.out.println("Average Response Time: " + String.format("%.2f ms", (Double) analytics.getMetrics().get("Average Response Time")));
        System.out.println("System Health: " + analytics.getMetrics().get("System Health"));
        System.out.println("=================================");
    }
    
    public static class SystemMetrics {
        private String name;
        private double value;
        private String unit;
        private LocalDateTime lastUpdated;
        
        public SystemMetrics(String name, double value, String unit) {
            this.name = name;
            this.value = value;
            this.unit = unit;
            this.lastUpdated = LocalDateTime.now();
        }
        
        // Getters and Setters
        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
        
        public double getValue() { return value; }
        public void setValue(double value) { this.value = value; }
        
        public String getUnit() { return unit; }
        public void setUnit(String unit) { this.unit = unit; }
        
        public LocalDateTime getLastUpdated() { return lastUpdated; }
        public void setLastUpdated(LocalDateTime lastUpdated) { this.lastUpdated = lastUpdated; }
        
        @Override
        public String toString() {
            return String.format("%s: %.2f %s", name, value, unit);
        }
    }
    
    public static class PerformanceLog {
        private String operation;
        private long responseTime;
        private boolean success;
        private LocalDateTime timestamp;
        
        public PerformanceLog(String operation, long responseTime, boolean success) {
            this.operation = operation;
            this.responseTime = responseTime;
            this.success = success;
            this.timestamp = LocalDateTime.now();
        }
        
        // Getters
        public String getOperation() { return operation; }
        public long getResponseTime() { return responseTime; }
        public boolean isSuccess() { return success; }
        public LocalDateTime getTimestamp() { return timestamp; }
        
        @Override
        public String toString() {
            return String.format("[%s] %s - %d ms - %s", 
                               timestamp.format(DateTimeFormatter.ofPattern("HH:mm:ss")), 
                               operation, responseTime, success ? "SUCCESS" : "FAILED");
        }
    }
    
    public static class SystemAnalytics {
        private Map<String, Object> metrics;
        private LocalDateTime timestamp;
        
        public SystemAnalytics(Map<String, Object> metrics, LocalDateTime timestamp) {
            this.metrics = metrics;
            this.timestamp = timestamp;
        }
        
        public Map<String, Object> getMetrics() { return metrics; }
        public LocalDateTime getTimestamp() { return timestamp; }
    }
}
