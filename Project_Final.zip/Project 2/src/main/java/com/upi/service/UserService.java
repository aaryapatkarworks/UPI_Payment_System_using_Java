package com.upi.service;

import com.upi.database.UserRepository;
import com.upi.model.User;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public class UserService {
    private static final Logger logger = LoggerFactory.getLogger(UserService.class);
    private static UserService instance;
    private UserRepository userRepository;

    private UserService() {
        this.userRepository = new UserRepository();
        initializeDemoUsers();
    }
    
    public static UserService getInstance() {
        if (instance == null) {
            instance = new UserService();
        }
        return instance;
    }
    
    private void initializeDemoUsers() {
        try {
            userRepository.initializeDemoUsers();
            logger.info("Demo users initialized from database");
        } catch (Exception e) {
            logger.error("Failed to initialize demo users", e);
        }
    }

    public User registerUser(User user) {
        try {
            // Generate unique user ID if not present
            if (user.getUserId() == null || user.getUserId().isEmpty()) {
                user.setUserId(UUID.randomUUID().toString());
            }
            
            // Generate UPI ID if not present
            if (user.getUpiId() == null || user.getUpiId().isEmpty()) {
                user.setUpiId(generateUpiId(user.getFullName()));
            }
            
            // Generate account number if not present
            if (user.getAccountNumber() == null || user.getAccountNumber().isEmpty()) {
                user.setAccountNumber(generateAccountNumber());
            }
            
            // Generate PAN number if not present
            if (user.getPanNumber() == null || user.getPanNumber().isEmpty()) {
                user.setPanNumber(generatePanNumber(user.getFullName()));
            }
            
            // Generate Aadhaar number if not present
            if (user.getAadhaarNumber() == null || user.getAadhaarNumber().isEmpty()) {
                user.setAadhaarNumber(generateAadhaarNumber());
            }
            
            // Set default account type if not present
            if (user.getAccountType() == null || user.getAccountType().isEmpty()) {
                user.setAccountType("SAVINGS");
            }
            
            // Set default KYC status
            if (user.getKycStatus() == null || user.getKycStatus().isEmpty()) {
                user.setKycStatus("VERIFIED");
            }
            
            User savedUser = userRepository.save(user);
            logger.info("User registered successfully: {}", savedUser.getUpiId());
            return savedUser;
            
        } catch (Exception e) {
            logger.error("Failed to register user", e);
            throw new RuntimeException("User registration failed", e);
        }
    }

    public Optional<User> findUserByUpiId(String upiId) {
        try {
            return userRepository.findByUpiId(upiId);
        } catch (Exception e) {
            logger.error("Failed to find user by UPI ID: {}", upiId, e);
            return Optional.empty();
        }
    }

    public Optional<User> findUserByPhoneNumber(String phoneNumber) {
        try {
            return userRepository.findByPhoneNumber(phoneNumber);
        } catch (Exception e) {
            logger.error("Failed to find user by phone: {}", phoneNumber, e);
            return Optional.empty();
        }
    }

    public Optional<User> findUserByEmail(String email) {
        try {
            return userRepository.findByEmail(email);
        } catch (Exception e) {
            logger.error("Failed to find user by email: {}", email, e);
            return Optional.empty();
        }
    }

    public boolean authenticateUser(String upiId, String pin) {
        try {
            Optional<User> userOpt = userRepository.findByUpiId(upiId);
            if (userOpt.isPresent()) {
                User user = userOpt.get();
                boolean authenticated = user.validatePin(pin);
                
                if (authenticated) {
                    updateUserLastLogin(upiId);
                    logger.info("User authenticated successfully: {}", upiId);
                } else {
                    logger.warn("Authentication failed for: {}", upiId);
                }
                
                return authenticated;
            }
            return false;
            
        } catch (Exception e) {
            logger.error("Authentication error for: {}", upiId, e);
            return false;
        }
    }

    public boolean updateBalance(String upiId, double newBalance) {
        try {
            return userRepository.updateBalance(upiId, newBalance);
        } catch (Exception e) {
            logger.error("Failed to update balance for: {}", upiId, e);
            return false;
        }
    }

    public boolean updateUserLastLogin(String upiId) {
        try {
            return userRepository.updateLastLogin(upiId);
        } catch (Exception e) {
            logger.error("Failed to update last login for: {}", upiId, e);
            return false;
        }
    }

    public List<User> getAllUsers() {
        try {
            return userRepository.findAll();
        } catch (Exception e) {
            logger.error("Failed to get all users", e);
            return List.of();
        }
    }

    public long getTotalUsers() {
        try {
            return userRepository.getTotalUsersCount();
        } catch (Exception e) {
            logger.error("Failed to get total users count", e);
            return 0;
        }
    }

    public double getTotalSystemBalance() {
        try {
            return userRepository.getTotalBalance();
        } catch (Exception e) {
            logger.error("Failed to get total system balance", e);
            return 0.0;
        }
    }

    private String generateUpiId(String fullName) {
        // Enhanced UPI ID generation algorithm for banking simulation
        String baseName = fullName.toLowerCase().replaceAll("[^a-zA-Z]", "");
        
        // Generate unique components
        long timestamp = System.currentTimeMillis();
        int randomSuffix = (int) (timestamp % 10000);
        String namePrefix = baseName.length() > 6 ? baseName.substring(0, 6) : baseName;
        
        // Create different UPI ID patterns based on user type
        String[] patterns = {
            namePrefix + randomSuffix + "@upi",
            namePrefix + "." + randomSuffix + "@upi", 
            namePrefix + randomSuffix + "@bank",
            namePrefix + "-" + randomSuffix + "@upi"
        };
        
        // Select pattern based on timestamp
        int patternIndex = (int) (timestamp % patterns.length);
        return patterns[patternIndex];
    }
    
    private String generateAccountNumber() {
        // Generate realistic 16-digit account number
        StringBuilder accountNumber = new StringBuilder();
        
        // Bank prefix (4 digits) - different for each bank
        String[] bankPrefixes = {"1234", "5678", "9012", "3456", "7890"};
        int prefixIndex = (int) (System.currentTimeMillis() % bankPrefixes.length);
        accountNumber.append(bankPrefixes[prefixIndex]);
        
        // Random 12 digits
        for (int i = 0; i < 12; i++) {
            accountNumber.append((int) (Math.random() * 10));
        }
        
        return accountNumber.toString();
    }
    
    // Enhanced PAN card generation
    private String generatePanNumber(String fullName) {
        // Generate realistic PAN card number: ABCDE1234F
        StringBuilder pan = new StringBuilder();
        
        // First 5 letters (based on name)
        String namePart = fullName.toUpperCase().replaceAll("[^A-Z]", "");
        for (int i = 0; i < 5; i++) {
            if (i < namePart.length()) {
                pan.append(namePart.charAt(i));
            } else {
                pan.append((char) ('A' + (Math.random() * 26)));
            }
        }
        
        // 4 digits
        for (int i = 0; i < 4; i++) {
            pan.append((int) (Math.random() * 10));
        }
        
        // 1 letter
        pan.append((char) ('A' + (Math.random() * 26)));
        
        return pan.toString();
    }
    
    // Enhanced Aadhaar number generation
    private String generateAadhaarNumber() {
        // Generate 12-digit Aadhaar number
        StringBuilder aadhaar = new StringBuilder();
        
        // First digit can't be 0
        aadhaar.append((int) (Math.random() * 9) + 1);
        
        // Remaining 11 digits
        for (int i = 0; i < 11; i++) {
            aadhaar.append((int) (Math.random() * 10));
        }
        
        return aadhaar.toString();
    }

    public double getUserBalance(String upiId) {
        try {
            Optional<User> user = userRepository.findByUpiId(upiId);
            if (user.isPresent()) {
                return user.get().getBalance();
            }
        } catch (Exception e) {
            logger.error("Error getting user balance: {}", e.getMessage());
        }
        return 0.0;
    }
    
    public boolean updateUserBalance(String upiId, double newBalance) {
        try {
            Optional<User> user = userRepository.findByUpiId(upiId);
            if (user.isPresent()) {
                return userRepository.updateBalance(upiId, newBalance);
            }
        } catch (Exception e) {
            logger.error("Error updating user balance: {}", e.getMessage());
        }
        return false;
    }

    // Database health check
    public boolean isDatabaseHealthy() {
        try {
            return userRepository != null && 
                   userRepository.getTotalUsersCount() >= 0; // Simple health check
        } catch (Exception e) {
            logger.error("Database health check failed", e);
            return false;
        }
    }

    // Get database statistics
    public String getDatabaseStats() {
        try {
            long totalUsers = getTotalUsers();
            double totalBalance = getTotalSystemBalance();
            
            return String.format("Users: %d, Total Balance: ₹%.2f, Database: %s", 
                               totalUsers, totalBalance, 
                               isDatabaseHealthy() ? "Healthy" : "Unhealthy");
        } catch (Exception e) {
            logger.error("Failed to get database stats", e);
            return "Database stats unavailable";
        }
    }
}
