package com.upi.database;

import com.upi.model.WalletCard;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class WalletRepository {
    private static final Logger logger = LoggerFactory.getLogger(WalletRepository.class);
    private final DatabaseService databaseService;
    
    public WalletRepository() {
        this.databaseService = DatabaseService.getInstance();
    }
    
    public WalletCard save(WalletCard card) {
        String sql = "INSERT OR REPLACE INTO wallet_cards " +
            "(card_id, user_upi_id, card_type, card_number, card_holder_name, " +
             "expiry_month, expiry_year, cvv, bank_name, is_default, is_active, added_date) " +
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = databaseService.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, card.getCardId());
            pstmt.setString(2, card.getUserUpiId());
            pstmt.setString(3, card.getCardType());
            pstmt.setString(4, card.getCardNumber());
            pstmt.setString(5, card.getCardHolderName());
            pstmt.setInt(6, card.getExpiryMonth());
            pstmt.setInt(7, card.getExpiryYear());
            pstmt.setString(8, card.getCvv());
            pstmt.setString(9, card.getBankName());
            pstmt.setBoolean(10, card.isDefault());
            pstmt.setBoolean(11, card.isActive());
            pstmt.setTimestamp(12, Timestamp.valueOf(card.getAddedDate()));
            
            pstmt.executeUpdate();
            logger.info("Wallet card saved: {}", card.getCardId());
            return card;
            
        } catch (SQLException e) {
            logger.error("Failed to save wallet card: {}", card.getCardId(), e);
            throw new RuntimeException("Failed to save wallet card", e);
        }
    }
    
    public List<WalletCard> findByUserUpiId(String userUpiId) {
        String sql = "SELECT * FROM wallet_cards WHERE user_upi_id = ? AND is_active = 1 ORDER BY added_date DESC";
        
        List<WalletCard> cards = new ArrayList<>();

        try (Connection conn = databaseService.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, userUpiId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                WalletCard card = mapResultSetToWalletCard(rs);
                cards.add(card);
            }
            
        } catch (SQLException e) {
            logger.error("Failed to find wallet cards for user: {}", userUpiId, e);
            throw new RuntimeException("Failed to find wallet cards", e);
        }

        return cards;
    }
    
    public Optional<WalletCard> findById(String cardId) {
        String sql = "SELECT * FROM wallet_cards WHERE card_id = ?";

        try (Connection conn = databaseService.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, cardId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                return Optional.of(mapResultSetToWalletCard(rs));
            }
            
        } catch (SQLException e) {
            logger.error("Failed to find wallet card: {}", cardId, e);
            throw new RuntimeException("Failed to find wallet card", e);
        }

        return Optional.empty();
    }
    
    public boolean setDefaultCard(String userUpiId, String cardId) {
        String sql = "UPDATE wallet_cards SET is_default = 0 WHERE user_upi_id = ?;" +
                    "UPDATE wallet_cards SET is_default = 1 WHERE card_id = ? AND user_upi_id = ?";

        try (Connection conn = databaseService.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, userUpiId);
            pstmt.setString(2, cardId);
            pstmt.setString(3, userUpiId);
            
            int rowsUpdated = pstmt.executeUpdate();
            logger.info("Set default card {} for user {}: {} rows affected", cardId, userUpiId, rowsUpdated);
            return rowsUpdated > 0;
            
        } catch (SQLException e) {
            logger.error("Failed to set default card: {}", cardId, e);
            throw new RuntimeException("Failed to set default card", e);
        }
    }
    
    public boolean deleteCard(String cardId) {
        String sql = "UPDATE wallet_cards SET is_active = 0 WHERE card_id = ?";

        try (Connection conn = databaseService.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, cardId);
            int rowsUpdated = pstmt.executeUpdate();
            logger.info("Deleted wallet card {}: {} rows affected", cardId, rowsUpdated);
            return rowsUpdated > 0;
            
        } catch (SQLException e) {
            logger.error("Failed to delete wallet card: {}", cardId, e);
            throw new RuntimeException("Failed to delete wallet card", e);
        }
    }
    
    public int getTotalCardsCount(String userUpiId) {
        String sql = "SELECT COUNT(*) FROM wallet_cards WHERE user_upi_id = ? AND is_active = 1";

        try (Connection conn = databaseService.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, userUpiId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                return rs.getInt(1);
            }
            
        } catch (SQLException e) {
            logger.error("Failed to get total cards count for user: {}", userUpiId, e);
            return 0;
        }

        return 0;
    }
    
    private WalletCard mapResultSetToWalletCard(ResultSet rs) throws SQLException {
        WalletCard card = new WalletCard();
        card.setCardId(rs.getString("card_id"));
        card.setUserUpiId(rs.getString("user_upi_id"));
        card.setCardType(rs.getString("card_type"));
        card.setCardNumber(rs.getString("card_number"));
        card.setCardHolderName(rs.getString("card_holder_name"));
        card.setExpiryMonth(rs.getInt("expiry_month"));
        card.setExpiryYear(rs.getInt("expiry_year"));
        card.setCvv(rs.getString("cvv"));
        card.setBankName(rs.getString("bank_name"));
        card.setDefault(rs.getBoolean("is_default"));
        card.setActive(rs.getBoolean("is_active"));
        
        Timestamp addedDate = rs.getTimestamp("added_date");
        if (addedDate != null) {
            card.setAddedDate(addedDate.toLocalDateTime());
        }
        
        return card;
    }
}
