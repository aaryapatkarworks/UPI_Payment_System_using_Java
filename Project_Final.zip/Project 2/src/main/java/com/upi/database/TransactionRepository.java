package com.upi.database;

import com.upi.model.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public class TransactionRepository {
    private static final Logger logger = LoggerFactory.getLogger(TransactionRepository.class);
    private final DatabaseService databaseService;

    public TransactionRepository() {
        this.databaseService = DatabaseService.getInstance();
    }

    public Transaction save(Transaction transaction) {
        String sql = "INSERT OR REPLACE INTO transactions " +
            "(transaction_id, from_upi_id, to_upi_id, amount, type, status, " +
             "remark, created_at, updated_at) " +
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = databaseService.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, transaction.getTransactionId());
            pstmt.setString(2, transaction.getFromUpiId());
            pstmt.setString(3, transaction.getToUpiId());
            pstmt.setDouble(4, transaction.getAmount());
            pstmt.setString(5, transaction.getType());
            pstmt.setString(6, transaction.getStatus());
            pstmt.setString(7, transaction.getRemark());
            pstmt.setTimestamp(8, Timestamp.valueOf(transaction.getCreatedAt()));
            pstmt.setTimestamp(9, Timestamp.valueOf(transaction.getUpdatedAt()));

            pstmt.executeUpdate();
            logger.info("Transaction saved: {}", transaction.getTransactionId());
            return transaction;

        } catch (SQLException e) {
            logger.error("Failed to save transaction: {}", transaction.getTransactionId(), e);
            throw new RuntimeException("Failed to save transaction", e);
        }
    }

    public Optional<Transaction> findById(String transactionId) {
        String sql = "SELECT * FROM transactions WHERE transaction_id = ?";

        try (Connection conn = databaseService.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, transactionId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                return Optional.of(mapRowToTransaction(rs));
            }
            return Optional.empty();

        } catch (SQLException e) {
            logger.error("Failed to find transaction: {}", transactionId, e);
            throw new RuntimeException("Failed to find transaction", e);
        }
    }

    public List<Transaction> findByUserUpiId(String upiId) {
        String sql = "SELECT * FROM transactions " +
            "WHERE (from_upi_id = ? OR to_upi_id = ?) " +
            "ORDER BY created_at DESC " +
            "LIMIT 50";
        
        List<Transaction> transactions = new ArrayList<>();

        try (Connection conn = databaseService.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, upiId);
            pstmt.setString(2, upiId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                transactions.add(mapRowToTransaction(rs));
            }

        } catch (SQLException e) {
            logger.error("Failed to find transactions for user: {}", upiId, e);
            throw new RuntimeException("Failed to find transactions", e);
        }

        return transactions;
    }

    public List<Transaction> findByUserUpiIdWithFilters(String upiId, String type, String status, int limit) {
        StringBuilder sql = new StringBuilder("SELECT * FROM transactions " +
            "WHERE (from_upi_id = ? OR to_upi_id = ?)");
        
        List<Object> params = new ArrayList<>();
        params.add(upiId);
        params.add(upiId);

        if (type != null && !type.isEmpty()) {
            sql.append(" AND type = ?");
            params.add(type);
        }

        if (status != null && !status.isEmpty()) {
            sql.append(" AND status = ?");
            params.add(status);
        }

        sql.append(" ORDER BY created_at DESC LIMIT ?");
        params.add(limit);

        List<Transaction> transactions = new ArrayList<>();

        try (Connection conn = databaseService.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql.toString())) {
            
            for (int i = 0; i < params.size(); i++) {
                pstmt.setObject(i + 1, params.get(i));
            }
            
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                transactions.add(mapRowToTransaction(rs));
            }

        } catch (SQLException e) {
            logger.error("Failed to find filtered transactions for user: {}", upiId, e);
            throw new RuntimeException("Failed to find transactions", e);
        }

        return transactions;
    }

    public boolean updateStatus(String transactionId, String newStatus) {
        String sql = "UPDATE transactions " +
            "SET status = ?, updated_at = CURRENT_TIMESTAMP " +
            "WHERE transaction_id = ?";

        try (Connection conn = databaseService.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, newStatus);
            pstmt.setString(2, transactionId);

            int rowsUpdated = pstmt.executeUpdate();
            logger.info("Transaction status updated to {} for {}: {} rows affected", 
                       newStatus, transactionId, rowsUpdated);
            return rowsUpdated > 0;

        } catch (SQLException e) {
            logger.error("Failed to update transaction status: {}", transactionId, e);
            throw new RuntimeException("Failed to update transaction status", e);
        }
    }

    public List<Transaction> findRecentTransactions(int limit) {
        String sql = "SELECT * FROM transactions ORDER BY created_at DESC LIMIT ?";
        List<Transaction> transactions = new ArrayList<>();

        try (Connection conn = databaseService.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, limit);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                transactions.add(mapRowToTransaction(rs));
            }

        } catch (SQLException e) {
            logger.error("Failed to find recent transactions", e);
            throw new RuntimeException("Failed to find transactions", e);
        }

        return transactions;
    }

    public long getTotalTransactionsCount() {
        String sql = "SELECT COUNT(*) FROM transactions";

        try (Connection conn = databaseService.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            if (rs.next()) {
                return rs.getLong(1);
            }

        } catch (SQLException e) {
            logger.error("Failed to get total transactions count", e);
        }

        return 0;
    }

    public long getSuccessfulTransactionsCount() {
        String sql = "SELECT COUNT(*) FROM transactions WHERE status = 'COMPLETED'";

        try (Connection conn = databaseService.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            if (rs.next()) {
                return rs.getLong(1);
            }

        } catch (SQLException e) {
            logger.error("Failed to get successful transactions count", e);
        }

        return 0;
    }

    public double getTotalTransactionAmount() {
        String sql = "SELECT SUM(amount) FROM transactions WHERE status = 'COMPLETED'";

        try (Connection conn = databaseService.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            if (rs.next()) {
                return rs.getDouble(1);
            }

        } catch (SQLException e) {
            logger.error("Failed to get total transaction amount", e);
        }

        return 0.0;
    }

    public double getTransactionAmountForUser(String upiId, String type) {
        String sql = "SELECT COALESCE(SUM(amount), 0) " +
            "FROM transactions " +
            "WHERE (from_upi_id = ? OR to_upi_id = ?) " +
            "AND type = ? " +
            "AND status = 'COMPLETED'";

        try (Connection conn = databaseService.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, upiId);
            pstmt.setString(2, upiId);
            pstmt.setString(3, type);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                return rs.getDouble(1);
            }

        } catch (SQLException e) {
            logger.error("Failed to get transaction amount for user: {}", upiId, e);
        }

        return 0.0;
    }

    private Transaction mapRowToTransaction(ResultSet rs) throws SQLException {
        Transaction transaction = new Transaction();
        transaction.setTransactionId(rs.getString("transaction_id"));
        transaction.setFromUpiId(rs.getString("from_upi_id"));
        transaction.setToUpiId(rs.getString("to_upi_id"));
        transaction.setAmount(rs.getDouble("amount"));
        transaction.setType(rs.getString("type"));
        transaction.setStatus(rs.getString("status"));
        transaction.setRemark(rs.getString("remark"));
        transaction.setCreatedAt(rs.getTimestamp("created_at").toLocalDateTime());
        transaction.setUpdatedAt(rs.getTimestamp("updated_at").toLocalDateTime());
        
        return transaction;
    }

    public void initializeDemoTransactions() {
        logger.info("Initializing demo transactions in database...");
        
        // Check if demo transactions already exist
        List<Transaction> existing = findRecentTransactions(1);
        if (!existing.isEmpty()) {
            logger.info("Demo transactions already exist in database");
            return;
        }

        // Create demo transactions
        Transaction txn1 = new Transaction("demo@upi", "john@upi", 500.00, "SENT", "Demo payment");
        txn1.setTransactionId(UUID.randomUUID().toString());
        txn1.setStatus("COMPLETED");
        save(txn1);

        Transaction txn2 = new Transaction("mary@upi", "demo@upi", 1000.00, "RECEIVED", "Payment received");
        txn2.setTransactionId(UUID.randomUUID().toString());
        txn2.setStatus("COMPLETED");
        save(txn2);

        Transaction txn3 = new Transaction("john@upi", "mary@upi", 250.00, "SENT", "Transfer");
        txn3.setTransactionId(UUID.randomUUID().toString());
        txn3.setStatus("COMPLETED");
        save(txn3);

        logger.info("Demo transactions initialized successfully");
    }

    public boolean saveTransaction(Transaction transaction) {
        String sql = "INSERT INTO transactions " +
            "(transaction_id, from_upi_id, to_upi_id, amount, type, status, remark, created_at, updated_at) " +
            "VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)";

        try (Connection conn = databaseService.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, transaction.getTransactionId());
            pstmt.setString(2, transaction.getFromUpiId());
            pstmt.setString(3, transaction.getToUpiId());
            pstmt.setDouble(4, transaction.getAmount());
            pstmt.setString(5, transaction.getType());
            pstmt.setString(6, transaction.getStatus());
            pstmt.setString(7, transaction.getRemark());
            
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
            
        } catch (SQLException e) {
            logger.error("Failed to save transaction: {}", e.getMessage());
            return false;
        }
    }
}
