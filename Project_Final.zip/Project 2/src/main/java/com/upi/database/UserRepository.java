package com.upi.database;

import com.upi.model.User;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public class UserRepository {
    private static final Logger logger = LoggerFactory.getLogger(UserRepository.class);
    private final DatabaseService databaseService;

    public UserRepository() {
        this.databaseService = DatabaseService.getInstance();
    }

    public User save(User user) {
        String sql = "INSERT OR REPLACE INTO users " +
            "(user_id, upi_id, full_name, phone_number, email, pin, bank_name, " +
             "account_number, balance, registration_date, last_login, linked_accounts, " +
             "is_active, profile_status) " +
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = databaseService.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, user.getUserId());
            pstmt.setString(2, user.getUpiId());
            pstmt.setString(3, user.getFullName());
            pstmt.setString(4, user.getPhoneNumber());
            pstmt.setString(5, user.getEmail());
            pstmt.setString(6, user.getPin());
            pstmt.setString(7, user.getBankName());
            pstmt.setString(8, user.getAccountNumber());
            pstmt.setDouble(9, user.getBalance());
            pstmt.setTimestamp(10, Timestamp.valueOf(user.getRegistrationDate()));
            pstmt.setTimestamp(11, user.getLastLogin() != null ? 
                Timestamp.valueOf(user.getLastLogin()) : null);
            pstmt.setString(12, String.join(",", user.getLinkedAccounts()));
            pstmt.setBoolean(13, user.isActive());
            pstmt.setString(14, user.getProfileStatus());

            pstmt.executeUpdate();
            logger.info("User saved successfully: {}", user.getUpiId());
            return user;

        } catch (SQLException e) {
            logger.error("Failed to save user: {}", user.getUpiId(), e);
            throw new RuntimeException("Failed to save user", e);
        }
    }

    public Optional<User> findByUpiId(String upiId) {
        String sql = "SELECT * FROM users WHERE upi_id = ? AND is_active = 1";

        try (Connection conn = databaseService.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, upiId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                return Optional.of(mapRowToUser(rs));
            }
            return Optional.empty();

        } catch (SQLException e) {
            logger.error("Failed to find user by UPI ID: {}", upiId, e);
            throw new RuntimeException("Failed to find user", e);
        }
    }

    public Optional<User> findByUserId(String userId) {
        String sql = "SELECT * FROM users WHERE user_id = ? AND is_active = 1";

        try (Connection conn = databaseService.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, userId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                return Optional.of(mapRowToUser(rs));
            }
            return Optional.empty();

        } catch (SQLException e) {
            logger.error("Failed to find user by ID: {}", userId, e);
            throw new RuntimeException("Failed to find user", e);
        }
    }

    public Optional<User> findByPhoneNumber(String phoneNumber) {
        String sql = "SELECT * FROM users WHERE phone_number = ? AND is_active = 1";

        try (Connection conn = databaseService.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, phoneNumber);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                return Optional.of(mapRowToUser(rs));
            }
            return Optional.empty();

        } catch (SQLException e) {
            logger.error("Failed to find user by phone: {}", phoneNumber, e);
            throw new RuntimeException("Failed to find user", e);
        }
    }

    public Optional<User> findByEmail(String email) {
        String sql = "SELECT * FROM users WHERE email = ? AND is_active = 1";

        try (Connection conn = databaseService.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, email);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                return Optional.of(mapRowToUser(rs));
            }
            return Optional.empty();

        } catch (SQLException e) {
            logger.error("Failed to find user by email: {}", email, e);
            throw new RuntimeException("Failed to find user", e);
        }
    }

    public List<User> findAll() {
        String sql = "SELECT * FROM users WHERE is_active = 1 ORDER BY registration_date DESC";
        List<User> users = new ArrayList<>();

        try (Connection conn = databaseService.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                users.add(mapRowToUser(rs));
            }

        } catch (SQLException e) {
            logger.error("Failed to find all users", e);
            throw new RuntimeException("Failed to find users", e);
        }

        return users;
    }

    public boolean updateBalance(String upiId, double newBalance) {
        String sql = "UPDATE users SET balance = ? WHERE upi_id = ? AND is_active = 1";

        try (Connection conn = databaseService.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setDouble(1, newBalance);
            pstmt.setString(2, upiId);

            int rowsUpdated = pstmt.executeUpdate();
            logger.info("Balance updated for {}: {} rows affected", upiId, rowsUpdated);
            return rowsUpdated > 0;

        } catch (SQLException e) {
            logger.error("Failed to update balance for: {}", upiId, e);
            throw new RuntimeException("Failed to update balance", e);
        }
    }

    public boolean updateLastLogin(String upiId) {
        String sql = "UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE upi_id = ? AND is_active = 1";

        try (Connection conn = databaseService.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, upiId);

            int rowsUpdated = pstmt.executeUpdate();
            logger.info("Last login updated for {}: {} rows affected", upiId, rowsUpdated);
            return rowsUpdated > 0;

        } catch (SQLException e) {
            logger.error("Failed to update last login for: {}", upiId, e);
            throw new RuntimeException("Failed to update last login", e);
        }
    }

    public boolean deactivateUser(String upiId) {
        String sql = "UPDATE users SET is_active = 0 WHERE upi_id = ?";

        try (Connection conn = databaseService.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, upiId);

            int rowsUpdated = pstmt.executeUpdate();
            logger.info("User deactivated {}: {} rows affected", upiId, rowsUpdated);
            return rowsUpdated > 0;

        } catch (SQLException e) {
            logger.error("Failed to deactivate user: {}", upiId, e);
            throw new RuntimeException("Failed to deactivate user", e);
        }
    }

    public long getTotalUsersCount() {
        String sql = "SELECT COUNT(*) FROM users WHERE is_active = 1";

        try (Connection conn = databaseService.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            if (rs.next()) {
                return rs.getLong(1);
            }

        } catch (SQLException e) {
            logger.error("Failed to get total users count", e);
        }

        return 0;
    }

    public double getTotalBalance() {
        String sql = "SELECT SUM(balance) FROM users WHERE is_active = 1";

        try (Connection conn = databaseService.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            if (rs.next()) {
                return rs.getDouble(1);
            }

        } catch (SQLException e) {
            logger.error("Failed to get total balance", e);
        }

        return 0.0;
    }

    private User mapRowToUser(ResultSet rs) throws SQLException {
        User user = new User();
        user.setUserId(rs.getString("user_id"));
        user.setUpiId(rs.getString("upi_id"));
        user.setFullName(rs.getString("full_name"));
        user.setPhoneNumber(rs.getString("phone_number"));
        user.setEmail(rs.getString("email"));
        user.setPin(rs.getString("pin"));
        user.setBankName(rs.getString("bank_name"));
        user.setAccountNumber(rs.getString("account_number"));
        user.setBalance(rs.getDouble("balance"));
        user.setRegistrationDate(rs.getTimestamp("registration_date").toLocalDateTime());
        
        Timestamp lastLogin = rs.getTimestamp("last_login");
        if (lastLogin != null) {
            user.setLastLogin(lastLogin.toLocalDateTime());
        }
        
        String linkedAccountsStr = rs.getString("linked_accounts");
        if (linkedAccountsStr != null && !linkedAccountsStr.isEmpty() && !linkedAccountsStr.equals("[]")) {
            List<String> linkedAccounts = List.of(linkedAccountsStr.split(","));
            user.setLinkedAccounts(new ArrayList<>(linkedAccounts));
        }
        
        user.setActive(rs.getBoolean("is_active"));
        user.setProfileStatus(rs.getString("profile_status"));
        
        return user;
    }

    public void initializeDemoUsers() {
        logger.info("Initializing demo users in database...");
        
        // Check if demo users already exist
        if (findByUpiId("demo@upi").isPresent()) {
            logger.info("Demo users already exist in database");
            return;
        }

        // Create demo users
        User demoUser = new User("Demo User", "9876543210", "demo@upi.com", "1234", "State Bank of India");
        demoUser.setUserId(UUID.randomUUID().toString());
        demoUser.setUpiId("demo@upi");
        demoUser.setBalance(15000.00);
        save(demoUser);

        User johnUser = new User("John Doe", "9876543211", "john@upi.com", "5678", "HDFC Bank");
        johnUser.setUserId(UUID.randomUUID().toString());
        johnUser.setUpiId("john@upi");
        johnUser.setBalance(8000.00);
        save(johnUser);

        User maryUser = new User("Mary Smith", "9876543212", "mary@upi.com", "9012", "ICICI Bank");
        maryUser.setUserId(UUID.randomUUID().toString());
        maryUser.setUpiId("mary@upi");
        maryUser.setBalance(12000.00);
        save(maryUser);

        logger.info("Demo users initialized successfully");
    }
}
