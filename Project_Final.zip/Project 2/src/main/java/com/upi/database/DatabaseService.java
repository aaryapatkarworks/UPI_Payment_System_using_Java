package com.upi.database;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.io.File;
import java.nio.file.Paths;

public class DatabaseService {
    private static final Logger logger = LoggerFactory.getLogger(DatabaseService.class);
    private static DatabaseService instance;
    private HikariDataSource dataSource;
    private final String DB_PATH = "smart_upi_system.db";

    private DatabaseService() {
        initializeDatabase();
    }

    public static synchronized DatabaseService getInstance() {
        if (instance == null) {
            instance = new DatabaseService();
        }
        return instance;
    }

    private void initializeDatabase() {
        try {
            // Configure connection pool
            HikariConfig config = new HikariConfig();
            config.setJdbcUrl("jdbc:sqlite:" + getDatabasePath());
            config.setDriverClassName("org.sqlite.JDBC");
            
            // Connection pool settings
            config.setMaximumPoolSize(10);
            config.setMinimumIdle(2);
            config.setConnectionTimeout(30000);
            config.setIdleTimeout(600000);
            config.setMaxLifetime(1800000);
            
            // SQLite specific settings
            config.addDataSourceProperty("cachePrepStmts", "true");
            config.addDataSourceProperty("prepStmtCacheSize", "250");
            config.addDataSourceProperty("prepStmtCacheSqlLimit", "2048");
            
            dataSource = new HikariDataSource(config);
            
            // Create tables
            createTables();
            
            logger.info("Database initialized successfully at: {}", getDatabasePath());
            
        } catch (Exception e) {
            logger.error("Failed to initialize database", e);
            throw new RuntimeException("Database initialization failed", e);
        }
    }

    private String getDatabasePath() {
        // Create database in project root directory
        String projectRoot = System.getProperty("user.dir");
        return Paths.get(projectRoot, DB_PATH).toString();
    }

    private void createTables() {
        String createUsersTable = "CREATE TABLE IF NOT EXISTS users (" +
            "user_id TEXT PRIMARY KEY," +
            "upi_id TEXT UNIQUE NOT NULL," +
            "full_name TEXT NOT NULL," +
            "phone_number TEXT NOT NULL," +
            "email TEXT NOT NULL," +
            "pin TEXT NOT NULL," +
            "bank_name TEXT NOT NULL," +
            "account_number TEXT NOT NULL," +
            "pan_number TEXT UNIQUE," +
            "aadhaar_number TEXT UNIQUE," +
            "balance REAL DEFAULT 10000.00," +
            "registration_date DATETIME DEFAULT CURRENT_TIMESTAMP," +
            "last_login DATETIME," +
            "linked_accounts TEXT DEFAULT '[]'," +
            "is_active BOOLEAN DEFAULT 1," +
            "profile_status TEXT DEFAULT 'VERIFIED'," +
            "kyc_status TEXT DEFAULT 'PENDING'," +
            "account_type TEXT DEFAULT 'SAVINGS'" +
            ")";

        String createTransactionsTable = "CREATE TABLE IF NOT EXISTS transactions (" +
            "transaction_id TEXT PRIMARY KEY," +
            "from_upi_id TEXT NOT NULL," +
            "to_upi_id TEXT NOT NULL," +
            "amount REAL NOT NULL," +
            "type TEXT NOT NULL CHECK (type IN ('SENT', 'RECEIVED', 'REQUESTED', 'FAILED'))," +
            "status TEXT NOT NULL CHECK (status IN ('PENDING', 'COMPLETED', 'FAILED', 'CANCELLED'))," +
            "remark TEXT DEFAULT ''," +
            "created_at DATETIME DEFAULT CURRENT_TIMESTAMP," +
            "updated_at DATETIME DEFAULT CURRENT_TIMESTAMP," +
            "FOREIGN KEY (from_upi_id) REFERENCES users(upi_id)," +
            "FOREIGN KEY (to_upi_id) REFERENCES users(upi_id)" +
            ")";

        String createPaymentRequestsTable = "CREATE TABLE IF NOT EXISTS payment_requests (" +
            "request_id TEXT PRIMARY KEY," +
            "from_upi_id TEXT NOT NULL," +
            "to_upi_id TEXT NOT NULL," +
            "amount REAL NOT NULL," +
            "remark TEXT DEFAULT ''," +
            "status TEXT NOT NULL CHECK (status IN ('PENDING', 'ACCEPTED', 'REJECTED', 'EXPIRED'))," +
            "created_at DATETIME DEFAULT CURRENT_TIMESTAMP," +
            "expires_at DATETIME," +
            "FOREIGN KEY (from_upi_id) REFERENCES users(upi_id)," +
            "FOREIGN KEY (to_upi_id) REFERENCES users(upi_id)" +
            ")";

        String createSystemLogsTable = "CREATE TABLE IF NOT EXISTS system_logs (" +
            "log_id INTEGER PRIMARY KEY AUTOINCREMENT," +
            "operation TEXT NOT NULL," +
            "response_time_ms INTEGER," +
            "success BOOLEAN NOT NULL," +
            "user_id TEXT," +
            "details TEXT DEFAULT ''," +
            "created_at DATETIME DEFAULT CURRENT_TIMESTAMP," +
            "FOREIGN KEY (user_id) REFERENCES users(upi_id)" +
            ")";

        String createWalletTable = "CREATE TABLE IF NOT EXISTS wallet_cards (" +
            "card_id TEXT PRIMARY KEY," +
            "user_upi_id TEXT NOT NULL," +
            "card_type TEXT NOT NULL CHECK (card_type IN ('DEBIT', 'CREDIT'))," +
            "card_number TEXT NOT NULL," +
            "card_holder_name TEXT NOT NULL," +
            "expiry_month INTEGER NOT NULL," +
            "expiry_year INTEGER NOT NULL," +
            "cvv TEXT NOT NULL," +
            "bank_name TEXT NOT NULL," +
            "is_default BOOLEAN DEFAULT 0," +
            "is_active BOOLEAN DEFAULT 1," +
            "added_date DATETIME DEFAULT CURRENT_TIMESTAMP," +
            "FOREIGN KEY (user_upi_id) REFERENCES users(upi_id)" +
            ")";

        String createIndexes = "CREATE INDEX IF NOT EXISTS idx_users_upi_id ON users(upi_id);" +
            "CREATE INDEX IF NOT EXISTS idx_users_phone ON users(phone_number);" +
            "CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);" +
            "CREATE INDEX IF NOT EXISTS idx_users_pan ON users(pan_number);" +
            "CREATE INDEX IF NOT EXISTS idx_users_aadhaar ON users(aadhaar_number);" +
            "CREATE INDEX IF NOT EXISTS idx_transactions_from ON transactions(from_upi_id);" +
            "CREATE INDEX IF NOT EXISTS idx_transactions_to ON transactions(to_upi_id);" +
            "CREATE INDEX IF NOT EXISTS idx_transactions_date ON transactions(created_at);" +
            "CREATE INDEX IF NOT EXISTS idx_payment_requests_from ON payment_requests(from_upi_id);" +
            "CREATE INDEX IF NOT EXISTS idx_payment_requests_to ON payment_requests(to_upi_id);" +
            "CREATE INDEX IF NOT EXISTS idx_system_logs_operation ON system_logs(operation);" +
            "CREATE INDEX IF NOT EXISTS idx_system_logs_date ON system_logs(created_at);" +
            "CREATE INDEX IF NOT EXISTS idx_wallet_cards_user ON wallet_cards(user_upi_id)";

        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement()) {
            
            // Execute all table creation statements
            stmt.execute(createUsersTable);
            stmt.execute(createTransactionsTable);
            stmt.execute(createPaymentRequestsTable);
            stmt.execute(createSystemLogsTable);
            stmt.execute(createWalletTable);
            stmt.execute(createIndexes);
            
            logger.info("All database tables created successfully");
            
        } catch (SQLException e) {
            logger.error("Failed to create database tables", e);
            throw new RuntimeException("Table creation failed", e);
        }
    }

    public Connection getConnection() throws SQLException {
        return dataSource.getConnection();
    }

    public void close() {
        if (dataSource != null && !dataSource.isClosed()) {
            dataSource.close();
            logger.info("Database connection pool closed");
        }
    }

    public boolean isHealthy() {
        try (Connection conn = getConnection()) {
            return conn.isValid(5); // Test connection with 5 second timeout
        } catch (SQLException e) {
            logger.error("Database health check failed", e);
            return false;
        }
    }

    public void backupDatabase(String backupPath) {
        try {
            File dbFile = new File(getDatabasePath());
            File backupFile = new File(backupPath);
            
            if (dbFile.exists()) {
                // Simple file copy for SQLite backup
                java.nio.file.Files.copy(dbFile.toPath(), backupFile.toPath(), 
                    java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                logger.info("Database backed up to: {}", backupPath);
            } else {
                logger.warn("Database file not found for backup");
            }
        } catch (Exception e) {
            logger.error("Database backup failed", e);
            throw new RuntimeException("Backup failed", e);
        }
    }

    public long getDatabaseSize() {
        try {
            File dbFile = new File(getDatabasePath());
            return dbFile.exists() ? dbFile.length() : 0;
        } catch (Exception e) {
            logger.error("Failed to get database size", e);
            return 0;
        }
    }

    public void vacuumDatabase() {
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement()) {
            stmt.execute("VACUUM");
            logger.info("Database vacuum completed");
        } catch (SQLException e) {
            logger.error("Database vacuum failed", e);
        }
    }
}
