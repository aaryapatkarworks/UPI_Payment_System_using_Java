package com.upi;

import com.upi.database.WalletRepository;
import com.upi.model.WalletCard;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.time.YearMonth;

public class EditCardScreen {
    private Stage primaryStage;
    private String currentUserUpiId;
    private WalletCard existingCard;
    private ComboBox<String> typeComboBox;

    public EditCardScreen(Stage primaryStage, String currentUserUpiId, WalletCard existingCard) {
        this.primaryStage = primaryStage;
        this.currentUserUpiId = currentUserUpiId;
        this.existingCard = existingCard;
    }

    public void show() {
        VBox layout = new VBox(15);
        layout.setAlignment(Pos.CENTER);
        layout.setPadding(new Insets(25));
        layout.setStyle("-fx-background-color: #f0f8ff;");

        // Header
        Text header = new Text("Edit Card");
        header.setFont(Font.font("Arial", FontWeight.BOLD, 24));
        header.setFill(Color.web("#FF9800"));
        layout.getChildren().add(header);

        // Form Grid
        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setStyle("-fx-background-color: white; -fx-border-color: #e0e0e0; -fx-border-width: 1; -fx-border-radius: 10; -fx-padding: 20;");
        grid.setPrefWidth(500);

        // Card Type
        Label typeLabel = new Label("Card Type:");
        grid.add(typeLabel, 0, 0);

        typeComboBox = new ComboBox<>();
        typeComboBox.getItems().addAll("DEBIT", "CREDIT");
        typeComboBox.setValue(existingCard.getCardType());
        grid.add(typeComboBox, 1, 0);

        // Card Number (read-only - masked)
        Label numberLabel = new Label("Card Number:");
        grid.add(numberLabel, 0, 1);

        TextField numberField = new TextField();
        numberField.setText(existingCard.getCardNumber());
        numberField.setEditable(false);
        numberField.setStyle("-fx-opacity: 0.7;");
        grid.add(numberField, 1, 1);

        // Card Holder Name
        Label holderLabel = new Label("Card Holder Name:");
        grid.add(holderLabel, 0, 2);

        TextField holderField = new TextField();
        holderField.setText(existingCard.getCardHolderName());
        holderField.setPromptText("John Doe");
        grid.add(holderField, 1, 2);

        // Expiry Month
        Label monthLabel = new Label("Expiry Month:");
        grid.add(monthLabel, 0, 3);

        ComboBox<String> monthComboBox = new ComboBox<>();
        for (int i = 1; i <= 12; i++) {
            monthComboBox.getItems().add(String.format("%02d", i));
        }
        monthComboBox.setValue(String.format("%02d", existingCard.getExpiryMonth()));
        grid.add(monthComboBox, 1, 3);

        // Expiry Year
        Label yearLabel = new Label("Expiry Year:");
        grid.add(yearLabel, 0, 4);

        ComboBox<String> yearComboBox = new ComboBox<>();
        int currentYear = java.time.Year.now().getValue();
        for (int i = currentYear; i <= currentYear + 10; i++) {
            yearComboBox.getItems().add(String.valueOf(i));
        }
        yearComboBox.setValue(String.valueOf(existingCard.getExpiryYear()));
        grid.add(yearComboBox, 1, 4);

        // CVV
        Label cvvLabel = new Label("CVV:");
        grid.add(cvvLabel, 0, 5);

        PasswordField cvvField = new PasswordField();
        cvvField.setText(existingCard.getCvv());
        cvvField.setPromptText("123");
        grid.add(cvvField, 1, 5);

        // Bank Name
        Label bankLabel = new Label("Bank Name:");
        grid.add(bankLabel, 0, 6);

        TextField bankField = new TextField();
        bankField.setText(existingCard.getBankName());
        bankField.setPromptText("State Bank of India");
        grid.add(bankField, 1, 6);

        // Default Card Checkbox
        CheckBox defaultCheckBox = new CheckBox("Set as default payment method");
        defaultCheckBox.setSelected(existingCard.isDefault());
        grid.add(defaultCheckBox, 1, 7);

        layout.getChildren().add(grid);

        // Action Buttons
        HBox buttonBox = new HBox(15);
        buttonBox.setAlignment(Pos.CENTER);

        Button saveBtn = new Button("Save Changes");
        saveBtn.setStyle("-fx-background-color: #FF9800; -fx-text-fill: white; -fx-padding: 12 24; -fx-font-size: 14px; -fx-border-radius: 25; -fx-background-radius: 25;");
        saveBtn.setPrefWidth(150);

        Button cancelBtn = new Button("Cancel");
        cancelBtn.setStyle("-fx-background-color: #6c757d; -fx-text-fill: white; -fx-padding: 12 24; -fx-font-size: 14px; -fx-border-radius: 25; -fx-background-radius: 25;");
        cancelBtn.setPrefWidth(150);

        buttonBox.getChildren().addAll(saveBtn, cancelBtn);
        layout.getChildren().add(buttonBox);

        // Status Message
        Text actiontarget = new Text();
        actiontarget.setFont(Font.font("Arial", 14));
        layout.getChildren().add(actiontarget);

        // Button Actions
        saveBtn.setOnAction(e -> {
            if (validateForm(holderField, monthComboBox, yearComboBox, cvvField, bankField, actiontarget)) {
                saveCard(holderField, monthComboBox, yearComboBox, cvvField, bankField, defaultCheckBox.isSelected(), actiontarget);
            }
        });

        cancelBtn.setOnAction(e -> {
            WalletScreen walletScreen = new WalletScreen(primaryStage, currentUserUpiId);
            walletScreen.show();
        });

        Scene scene = new Scene(layout, 600, 700);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Smart UPI System - Edit Card");
        primaryStage.show();
    }

    private boolean validateForm(TextField holderField, ComboBox<String> monthComboBox, 
                                ComboBox<String> yearComboBox, PasswordField cvvField, 
                                TextField bankField, Text actiontarget) {
        
        if (holderField.getText().trim().isEmpty()) {
            actiontarget.setFill(Color.FIREBRICK);
            actiontarget.setText("Card holder name is required.");
            return false;
        }

        if (monthComboBox.getValue() == null || yearComboBox.getValue() == null) {
            actiontarget.setFill(Color.FIREBRICK);
            actiontarget.setText("Expiry date is required.");
            return false;
        }

        if (cvvField.getText().trim().isEmpty()) {
            actiontarget.setFill(Color.FIREBRICK);
            actiontarget.setText("CVV is required.");
            return false;
        }

        if (cvvField.getText().length() != 3 || !cvvField.getText().matches("\\d{3}")) {
            actiontarget.setFill(Color.FIREBRICK);
            actiontarget.setText("CVV must be 3 digits.");
            return false;
        }

        if (bankField.getText().trim().isEmpty()) {
            actiontarget.setFill(Color.FIREBRICK);
            actiontarget.setText("Bank name is required.");
            return false;
        }

        // Check if card is expired
        int month = Integer.parseInt(monthComboBox.getValue());
        int year = Integer.parseInt(yearComboBox.getValue());
        YearMonth expiry = YearMonth.of(year, month);
        if (expiry.isBefore(java.time.YearMonth.now())) {
            actiontarget.setFill(Color.FIREBRICK);
            actiontarget.setText("Card has expired. Please use a valid card.");
            return false;
        }

        return true;
    }

    private void saveCard(TextField holderField, ComboBox<String> monthComboBox, 
                          ComboBox<String> yearComboBox, PasswordField cvvField, 
                          TextField bankField, boolean isDefault, Text actiontarget) {
        
        try {
            WalletRepository walletRepo = new WalletRepository();
            
            // Update existing card details
            existingCard.setCardType(typeComboBox.getValue());
            existingCard.setCardHolderName(holderField.getText());
            existingCard.setExpiryMonth(Integer.parseInt(monthComboBox.getValue()));
            existingCard.setExpiryYear(Integer.parseInt(yearComboBox.getValue()));
            existingCard.setCvv(cvvField.getText());
            existingCard.setBankName(bankField.getText());
            existingCard.setDefault(isDefault);
            
            // Save updated card
            WalletCard updatedCard = walletRepo.save(existingCard);
            
            actiontarget.setFill(Color.GREEN);
            actiontarget.setText("Card updated successfully!");
            
            // Go back to wallet after 2 seconds
            javafx.application.Platform.runLater(() -> {
                try {
                    Thread.sleep(2000);
                    WalletScreen walletScreen = new WalletScreen(primaryStage, currentUserUpiId);
                    walletScreen.show();
                } catch (InterruptedException ex) {
                    Thread.currentThread().interrupt();
                }
            });
            
        } catch (Exception e) {
            actiontarget.setFill(Color.FIREBRICK);
            actiontarget.setText("Error updating card: " + e.getMessage());
        }
    }
}
