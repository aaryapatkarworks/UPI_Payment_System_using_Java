package com.upi;

import com.upi.model.User;
import com.upi.service.UserService;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.time.format.DateTimeFormatter;

public class ProfileScreen {
    private Stage primaryStage;
    private User currentUser;
    private UserService userService;

    public ProfileScreen(Stage primaryStage, User currentUser) {
        this.primaryStage = primaryStage;
        this.currentUser = currentUser;
        this.userService = UserService.getInstance();
    }

    public void show() {
        ScrollPane scrollPane = new ScrollPane();
        scrollPane.setFitToWidth(true);
        scrollPane.setStyle("-fx-background: #f5f5f5;");

        VBox mainContainer = new VBox(20);
        mainContainer.setPadding(new Insets(20));
        mainContainer.setStyle("-fx-background-color: #f5f5f5;");

        // Header
        VBox header = createHeader();
        mainContainer.getChildren().add(header);

        // Profile Information
        VBox profileSection = createProfileSection();
        mainContainer.getChildren().add(profileSection);

        // Account Information
        VBox accountSection = createAccountSection();
        mainContainer.getChildren().add(accountSection);

        // Linked Accounts
        VBox linkedAccountsSection = createLinkedAccountsSection();
        mainContainer.getChildren().add(linkedAccountsSection);

        // Actions
        HBox actionsSection = createActionsSection();
        mainContainer.getChildren().add(actionsSection);

        scrollPane.setContent(mainContainer);

        Scene scene = new Scene(scrollPane, 600, 700);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Smart UPI System - Profile");
        primaryStage.show();
    }

    private VBox createHeader() {
        VBox header = new VBox(10);
        header.setStyle("-fx-background-color: #795548; -fx-padding: 20; -fx-background-radius: 10;");
        header.setAlignment(Pos.CENTER);

        Text title = new Text("User Profile");
        title.setFont(Font.font("Arial", FontWeight.BOLD, 24));
        title.setFill(Color.WHITE);

        Text subtitle = new Text("Manage your account information");
        subtitle.setFont(Font.font("Arial", FontWeight.NORMAL, 14));
        subtitle.setFill(Color.WHITE);

        header.getChildren().addAll(title, subtitle);
        return header;
    }

    private VBox createProfileSection() {
        VBox section = new VBox(15);
        section.setStyle("-fx-background-color: white; -fx-padding: 20; -fx-border-radius: 10; -fx-background-radius: 10;");

        Text title = new Text("Personal Information");
        title.setFont(Font.font("Arial", FontWeight.BOLD, 18));
        section.getChildren().add(title);

        GridPane grid = new GridPane();
        grid.setHgap(15);
        grid.setVgap(10);

        // User ID
        addLabelAndField(grid, "User ID:", currentUser.getUserId(), 0);
        
        // Full Name
        addLabelAndField(grid, "Full Name:", currentUser.getFullName(), 1);
        
        // Email
        addLabelAndField(grid, "Email:", currentUser.getEmail(), 2);
        
        // Phone Number
        addLabelAndField(grid, "Phone Number:", currentUser.getPhoneNumber(), 3);
        
        // UPI ID
        addLabelAndField(grid, "UPI ID:", currentUser.getUpiId(), 4);
        
        // Registration Date
        String regDate = currentUser.getRegistrationDate().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));
        addLabelAndField(grid, "Registration Date:", regDate, 5);

        section.getChildren().add(grid);
        return section;
    }

    private VBox createAccountSection() {
        VBox section = new VBox(15);
        section.setStyle("-fx-background-color: white; -fx-padding: 20; -fx-border-radius: 10; -fx-background-radius: 10;");

        Text title = new Text("Account Information");
        title.setFont(Font.font("Arial", FontWeight.BOLD, 18));
        section.getChildren().add(title);

        GridPane grid = new GridPane();
        grid.setHgap(15);
        grid.setVgap(10);

        // Bank Name
        addLabelAndField(grid, "Bank Name:", currentUser.getBankName(), 0);
        
        // Account Number
        addLabelAndField(grid, "Account Number:", currentUser.getAccountNumber(), 1);
        
        // Balance
        String balance = String.format("₹%.2f", currentUser.getBalance());
        addLabelAndField(grid, "Available Balance:", balance, 2);
        
        // Profile Status
        addLabelAndField(grid, "Profile Status:", currentUser.getProfileStatus(), 3);
        
        // Account Status
        String status = currentUser.isActive() ? "Active" : "Inactive";
        addLabelAndField(grid, "Account Status:", status, 4);

        section.getChildren().add(grid);
        return section;
    }

    private VBox createLinkedAccountsSection() {
        VBox section = new VBox(15);
        section.setStyle("-fx-background-color: white; -fx-padding: 20; -fx-border-radius: 10; -fx-background-radius: 10;");

        Text title = new Text("Linked Accounts");
        title.setFont(Font.font("Arial", FontWeight.BOLD, 18));
        section.getChildren().add(title);

        ListView<String> linkedAccountsList = new ListView<>();
        linkedAccountsList.setPrefHeight(100);
        
        if (currentUser.getLinkedAccounts().isEmpty()) {
            linkedAccountsList.getItems().add("No linked accounts");
        } else {
            linkedAccountsList.getItems().addAll(currentUser.getLinkedAccounts());
        }

        section.getChildren().add(linkedAccountsList);
        return section;
    }

    private HBox createActionsSection() {
        HBox actions = new HBox(15);
        actions.setAlignment(Pos.CENTER);

        Button editProfileBtn = new Button("Edit Profile");
        editProfileBtn.setStyle("-fx-background-color: #2196F3; -fx-text-fill: white; -fx-padding: 10 20; -fx-font-size: 14px;");
        editProfileBtn.setOnAction(e -> showEditProfileDialog());

        Button changePinBtn = new Button("Change PIN");
        changePinBtn.setStyle("-fx-background-color: #FF9800; -fx-text-fill: white; -fx-padding: 10 20; -fx-font-size: 14px;");
        changePinBtn.setOnAction(e -> showChangePinDialog());

        Button deactivateBtn = new Button("Deactivate Account");
        deactivateBtn.setStyle("-fx-background-color: #f44336; -fx-text-fill: white; -fx-padding: 10 20; -fx-font-size: 14px;");
        deactivateBtn.setOnAction(e -> showDeactivateDialog());

        Button backBtn = new Button("Back to Dashboard");
        backBtn.setStyle("-fx-background-color: #607D8B; -fx-text-fill: white; -fx-padding: 10 20; -fx-font-size: 14px;");
        backBtn.setOnAction(e -> {
            Dashboard dashboard = new Dashboard(primaryStage, currentUser.getUpiId());
            dashboard.show();
        });

        actions.getChildren().addAll(editProfileBtn, changePinBtn, deactivateBtn, backBtn);
        return actions;
    }

    private void addLabelAndField(GridPane grid, String labelText, String value, int row) {
        Label label = new Label(labelText);
        label.setFont(Font.font("Arial", FontWeight.BOLD, 12));
        grid.add(label, 0, row);

        TextField field = new TextField(value);
        field.setEditable(false);
        field.setStyle("-fx-background-color: #f0f0f0; -fx-text-fill: black;");
        grid.add(field, 1, row);
    }

    private void showEditProfileDialog() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Edit Profile");
        alert.setHeaderText("Profile Editing");
        alert.setContentText("Profile editing feature would allow users to update their personal information.\nThis would include forms to edit name, email, and phone number.");
        alert.showAndWait();
    }

    private void showChangePinDialog() {
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle("Change PIN");
        dialog.setHeaderText("Change Your UPI PIN");

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);

        PasswordField oldPinField = new PasswordField();
        oldPinField.setPromptText("Current PIN");

        PasswordField newPinField = new PasswordField();
        newPinField.setPromptText("New PIN (4 digits)");

        PasswordField confirmPinField = new PasswordField();
        confirmPinField.setPromptText("Confirm New PIN");

        grid.add(new Label("Current PIN:"), 0, 0);
        grid.add(oldPinField, 1, 0);
        grid.add(new Label("New PIN:"), 0, 1);
        grid.add(newPinField, 1, 1);
        grid.add(new Label("Confirm PIN:"), 0, 2);
        grid.add(confirmPinField, 1, 2);

        dialog.getDialogPane().setContent(grid);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        dialog.showAndWait().ifPresent(result -> {
            if (result == ButtonType.OK) {
                // Validate and change PIN
                String oldPin = oldPinField.getText();
                String newPin = newPinField.getText();
                String confirmPin = confirmPinField.getText();

                if (!currentUser.validatePin(oldPin)) {
                    showAlert("Error", "Current PIN is incorrect.");
                } else if (!newPin.equals(confirmPin)) {
                    showAlert("Error", "New PINs do not match.");
                } else if (newPin.length() != 4 || !newPin.matches("\\d+")) {
                    showAlert("Error", "PIN must be 4 digits.");
                } else {
                    currentUser.setPin(newPin);
                    showAlert("Success", "PIN changed successfully!");
                }
            }
        });
    }

    private void showDeactivateDialog() {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Deactivate Account");
        alert.setHeaderText("Are you sure you want to deactivate your account?");
        alert.setContentText("This action can be reversed by contacting support.");

        alert.showAndWait().ifPresent(result -> {
            if (result == ButtonType.OK) {
                currentUser.setActive(false);
                showAlert("Account Deactivated", "Your account has been deactivated. You will be logged out.");
                // Return to login screen
                new Main().start(primaryStage);
            }
        });
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
