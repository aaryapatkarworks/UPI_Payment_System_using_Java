package com.upi;

import com.upi.service.UserService;
import com.upi.service.MonitoringService;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Main extends Application {
    private UserService userService;
    private MonitoringService monitoringService;
    
    @Override
    public void start(Stage primaryStage) {
        userService = UserService.getInstance();
        monitoringService = MonitoringService.getInstance();
        
        primaryStage.setTitle("Smart UPI System");
        
        // Create login screen
        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(25, 25, 25, 25));
        grid.setStyle("-fx-background-color: #f0f8ff;");

        Text scenetitle = new Text("Smart UPI System");
        scenetitle.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));
        grid.add(scenetitle, 0, 0, 2, 1);

        Label userName = new Label("User ID:");
        grid.add(userName, 0, 1);

        TextField userTextField = new TextField();
        userTextField.setPromptText("Enter your UPI ID");
        grid.add(userTextField, 1, 1);

        Label pw = new Label("PIN:");
        grid.add(pw, 0, 2);

        PasswordField pwBox = new PasswordField();
        pwBox.setPromptText("Enter 4-digit PIN");
        grid.add(pwBox, 1, 2);

        Button btn = new Button("Sign In");
        Button registerBtn = new Button("Register");
        
        HBox hbBtn = new HBox(10);
        hbBtn.setAlignment(Pos.BOTTOM_RIGHT);
        hbBtn.getChildren().addAll(btn, registerBtn);
        grid.add(hbBtn, 1, 4);

        final Text actiontarget = new Text();
        grid.add(actiontarget, 0, 6, 2, 1);

        btn.setOnAction(e -> {
            long startTime = System.currentTimeMillis();
            
            if (userTextField.getText().isEmpty() || pwBox.getText().isEmpty()) {
                actiontarget.setFill(Color.FIREBRICK);
                actiontarget.setText("Please enter both User ID and PIN");
                monitoringService.recordPerformanceLog("LOGIN", System.currentTimeMillis() - startTime, false);
            } else if (pwBox.getText().length() != 4) {
                actiontarget.setFill(Color.FIREBRICK);
                actiontarget.setText("PIN must be 4 digits");
                monitoringService.recordPerformanceLog("LOGIN", System.currentTimeMillis() - startTime, false);
            } else {
                // Authenticate user
                boolean authenticated = userService.authenticateUser(userTextField.getText(), pwBox.getText());
                
                if (authenticated) {
                    actiontarget.setFill(Color.GREEN);
                    actiontarget.setText("Login successful!");
                    monitoringService.recordPerformanceLog("LOGIN", System.currentTimeMillis() - startTime, true);
                    monitoringService.recordTransaction(true);
                    
                    // Open main dashboard
                    openDashboard(primaryStage, userTextField.getText());
                } else {
                    actiontarget.setFill(Color.FIREBRICK);
                    actiontarget.setText("Invalid UPI ID or PIN");
                    monitoringService.recordPerformanceLog("LOGIN", System.currentTimeMillis() - startTime, false);
                    monitoringService.recordTransaction(false);
                }
            }
        });

        registerBtn.setOnAction(e -> {
            openRegistrationScreen(primaryStage);
        });

        Scene scene = new Scene(grid, 400, 300);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void openDashboard(Stage primaryStage, String userId) {
        Dashboard dashboard = new Dashboard(primaryStage, userId);
        dashboard.show();
    }

    private void openRegistrationScreen(Stage primaryStage) {
        RegistrationScreen registration = new RegistrationScreen(primaryStage);
        registration.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
