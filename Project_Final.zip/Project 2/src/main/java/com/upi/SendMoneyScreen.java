package com.upi;

import com.upi.database.TransactionRepository;
import com.upi.model.Transaction;
import com.upi.service.UserService;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class SendMoneyScreen {
    private Stage primaryStage;
    private String userId;
    private double balance;

    public SendMoneyScreen(Stage primaryStage, String userId, double balance) {
        this.primaryStage = primaryStage;
        this.userId = userId;
        this.balance = balance;
    }

    public void show() {
        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(25, 25, 25, 25));
        grid.setStyle("-fx-background-color: #f0f8ff;");

        Text scenetitle = new Text("Send Money");
        scenetitle.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));
        grid.add(scenetitle, 0, 0, 2, 1);

        Label payeeLabel = new Label("Payee UPI ID:");
        grid.add(payeeLabel, 0, 1);

        TextField payeeField = new TextField();
        payeeField.setPromptText("Enter payee's UPI ID");
        grid.add(payeeField, 1, 1);

        Label amountLabel = new Label("Amount (₹):");
        grid.add(amountLabel, 0, 2);

        TextField amountField = new TextField();
        amountField.setPromptText("Enter amount");
        grid.add(amountField, 1, 2);

        Label remarkLabel = new Label("Remark:");
        grid.add(remarkLabel, 0, 3);

        TextField remarkField = new TextField();
        remarkField.setPromptText("Add a remark (optional)");
        grid.add(remarkField, 1, 3);

        Label pinLabel = new Label("Enter PIN:");
        grid.add(pinLabel, 0, 4);

        PasswordField pinField = new PasswordField();
        pinField.setPromptText("Enter 4-digit PIN");
        grid.add(pinField, 1, 4);

        // Balance display
        Text balanceText = new Text("Available Balance: ₹" + String.format("%.2f", balance));
        balanceText.setFont(Font.font("Arial", FontWeight.NORMAL, 12));
        balanceText.setFill(Color.DARKBLUE);
        grid.add(balanceText, 0, 5, 2, 1);

        Button sendBtn = new Button("Send Money");
        Button cancelBtn = new Button("Cancel");

        HBox hbBtn = new HBox(10);
        hbBtn.setAlignment(Pos.BOTTOM_RIGHT);
        hbBtn.getChildren().addAll(sendBtn, cancelBtn);
        grid.add(hbBtn, 1, 7);

        final Text actiontarget = new Text();
        grid.add(actiontarget, 0, 9, 2, 1);

        sendBtn.setOnAction(e -> {
            if (validateSendMoney(payeeField, amountField, pinField, actiontarget)) {
                double amount = Double.parseDouble(amountField.getText());
                
                try {
                    TransactionRepository transactionRepo = new TransactionRepository();
                    UserService userService = UserService.getInstance();
                    
                    if (amount > userService.getUserBalance(userId)) {
                        actiontarget.setFill(Color.FIREBRICK);
                        actiontarget.setText("Insufficient balance! Available: ₹" + String.format("%.2f", userService.getUserBalance(userId)));
                    } else {
                        // Update sender balance (debit)
                        double senderNewBalance = userService.getUserBalance(userId) - amount;
                        userService.updateUserBalance(userId, senderNewBalance);
                        
                        // Update receiver balance (credit)
                        double receiverCurrentBalance = userService.getUserBalance(payeeField.getText());
                        double receiverNewBalance = receiverCurrentBalance + amount;
                        userService.updateUserBalance(payeeField.getText(), receiverNewBalance);
                        
                        // Create only ONE transaction record for both parties
                        // This single record will be shown in both sender's and receiver's history
                        Transaction transaction = new Transaction(
                            userId,                 // Sender
                            payeeField.getText(),  // Receiver
                            amount,
                            "SENT",                // Type from sender's perspective
                            remarkField.getText(),
                            "COMPLETED"
                        );
                        
                        boolean success = transactionRepo.saveTransaction(transaction);
                        
                        if (success) {
                            actiontarget.setFill(Color.GREEN);
                            actiontarget.setText("₹" + amount + " sent successfully to " + payeeField.getText());
                            
                            // Go back to dashboard immediately after successful transaction
                            Dashboard dashboard = new Dashboard(primaryStage, userId);
                            dashboard.show();
                        } else {
                            actiontarget.setFill(Color.FIREBRICK);
                            actiontarget.setText("Transaction failed. Please try again.");
                        }
                    }
                } catch (Exception ex) {
                    actiontarget.setFill(Color.FIREBRICK);
                    actiontarget.setText("Error: " + ex.getMessage());
                }
            }
        });

        cancelBtn.setOnAction(e -> {
            Dashboard dashboard = new Dashboard(primaryStage, userId);
            dashboard.show();
        });

        Scene scene = new Scene(grid, 400, 400);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Smart UPI System - Send Money");
        primaryStage.show();
    }

    private boolean validateSendMoney(TextField payeeField, TextField amountField, 
                                     PasswordField pinField, Text actiontarget) {
        
        if (payeeField.getText().isEmpty()) {
            actiontarget.setFill(Color.FIREBRICK);
            actiontarget.setText("Please enter payee's UPI ID");
            return false;
        }
        
        if (!payeeField.getText().contains("@")) {
            actiontarget.setFill(Color.FIREBRICK);
            actiontarget.setText("Please enter a valid UPI ID");
            return false;
        }
        
        if (amountField.getText().isEmpty()) {
            actiontarget.setFill(Color.FIREBRICK);
            actiontarget.setText("Please enter amount");
            return false;
        }
        
        try {
            double amount = Double.parseDouble(amountField.getText());
            if (amount <= 0) {
                actiontarget.setFill(Color.FIREBRICK);
                actiontarget.setText("Amount must be greater than 0");
                return false;
            }
        } catch (NumberFormatException ex) {
            actiontarget.setFill(Color.FIREBRICK);
            actiontarget.setText("Please enter a valid amount");
            return false;
        }
        
        if (pinField.getText().length() != 4 || !pinField.getText().matches("\\d+")) {
            actiontarget.setFill(Color.FIREBRICK);
            actiontarget.setText("PIN must be 4 digits");
            return false;
        }
        
        return true;
    }
}
