package com.upi;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.SnapshotParameters;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.WritableImage;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.awt.image.BufferedImage;
import java.util.HashMap;
import java.util.Map;

public class ReceiveMoneyScreen {
    private Stage primaryStage;
    private String userId;

    public ReceiveMoneyScreen(Stage primaryStage, String userId) {
        this.primaryStage = primaryStage;
        this.userId = userId;
    }

    public void show() {
        VBox mainContainer = new VBox(20);
        mainContainer.setPadding(new Insets(20));
        mainContainer.setStyle("-fx-background: linear-gradient(to bottom, #667eea 0%, #764ba2 100%);");

        // Header
        VBox header = createHeader();
        mainContainer.getChildren().add(header);

        // Main Content
        VBox content = createMainContent();
        mainContainer.getChildren().add(content);

        // Footer
        HBox footer = createFooter();
        mainContainer.getChildren().add(footer);

        ScrollPane scrollPane = new ScrollPane(mainContainer);
        scrollPane.setFitToWidth(true);
        scrollPane.setStyle("-fx-background: transparent;");

        Scene scene = new Scene(scrollPane, 450, 700);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Smart UPI System - Receive Money");
        primaryStage.show();
    }

    private VBox createHeader() {
        VBox header = new VBox(10);
        header.setStyle("-fx-background-color: rgba(255, 255, 255, 0.1); -fx-padding: 20; -fx-background-radius: 15;");
        header.setAlignment(Pos.CENTER);

        Text title = new Text("💰 Receive Money");
        title.setFont(Font.font("Arial", FontWeight.BOLD, 24));
        title.setFill(Color.WHITE);

        Text subtitle = new Text("Generate QR Code or Payment Request");
        subtitle.setFont(Font.font("Arial", FontWeight.NORMAL, 14));
        subtitle.setFill(Color.WHITE);

        header.getChildren().addAll(title, subtitle);
        return header;
    }

    private VBox createMainContent() {
        VBox content = new VBox(20);
        content.setAlignment(Pos.CENTER);

        // QR Code Section
        VBox qrSection = createQRSection();
        content.getChildren().add(qrSection);

        // UPI ID Display
        VBox upiSection = createUPISection();
        content.getChildren().add(upiSection);

        // Amount Request Section
        VBox requestSection = createRequestSection();
        content.getChildren().add(requestSection);

        return content;
    }

    private VBox createUPISection() {
        VBox upiSection = new VBox(10);
        upiSection.setAlignment(Pos.CENTER);

        Label upiIdLabel = new Label("Your UPI ID:");
        upiIdLabel.setFont(Font.font("Arial", FontWeight.NORMAL, 14));
        upiIdLabel.setStyle("-fx-text-fill: white;");

        TextField upiIdField = new TextField(userId + "@upi");
        upiIdField.setEditable(false);
        upiIdField.setStyle("-fx-background-color: #e0e0e0; -fx-text-fill: black;");
        upiIdField.setFont(Font.font("Arial", FontWeight.NORMAL, 14));

        upiSection.getChildren().addAll(upiIdLabel, upiIdField);
        return upiSection;
    }

    private VBox createRequestSection() {
        VBox requestSection = new VBox(10);
        requestSection.setAlignment(Pos.CENTER);

        Label amountLabel = new Label("Request Amount (₹):");
        amountLabel.setFont(Font.font("Arial", FontWeight.NORMAL, 14));
        amountLabel.setStyle("-fx-text-fill: white;");

        TextField amountField = new TextField();
        amountField.setPromptText("Enter amount to request (optional)");
        amountField.setFont(Font.font("Arial", FontWeight.NORMAL, 14));

        Label remarkLabel = new Label("Request Remark:");
        remarkLabel.setFont(Font.font("Arial", FontWeight.NORMAL, 14));
        remarkLabel.setStyle("-fx-text-fill: white;");

        TextField remarkField = new TextField();
        remarkField.setPromptText("Add a remark for the request");
        remarkField.setFont(Font.font("Arial", FontWeight.NORMAL, 14));

        Button generateRequestBtn = new Button("Generate Request Link");
        generateRequestBtn.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white; -fx-padding: 12 24; -fx-font-size: 14px; -fx-border-radius: 25; -fx-background-radius: 25;");
        generateRequestBtn.setOnAction(e -> {
            String amount = amountField.getText();
            String remark = remarkField.getText();

            if (amount.isEmpty()) {
                amount = "Any amount";
            } else {
                try {
                    double amt = Double.parseDouble(amount);
                    if (amt <= 0) {
                        amountField.setStyle("-fx-background-color: #FFC0CB;");
                        return;
                    }
                    amount = "₹" + amount;
                } catch (NumberFormatException ex) {
                    amountField.setStyle("-fx-background-color: #FFC0CB;");
                    return;
                }
            }

            if (remark.isEmpty()) {
                remark = "No remark";
            }

            // Show request details
            showRequestDetails(amount, remark);
        });

        requestSection.getChildren().addAll(amountLabel, amountField, remarkLabel, remarkField, generateRequestBtn);
        return requestSection;
    }

    private VBox createQRSection() {
        VBox qrSection = new VBox(10);
        qrSection.setAlignment(Pos.CENTER);

        Text qrLabel = new Text("📱 Scan QR Code to Pay");
        qrLabel.setFont(Font.font("Arial", FontWeight.BOLD, 16));
        qrLabel.setFill(Color.WHITE);

        // Enhanced QR Code with actual generation
        VBox qrBox = new VBox();
        qrBox.setStyle("-fx-background-color: white; -fx-border: 3px solid #4CAF50; -fx-padding: 15; -fx-border-radius: 10; -fx-background-radius: 10;");
        qrBox.setPrefSize(200, 200);
        qrBox.setAlignment(Pos.CENTER);

        try {
            // Generate actual QR code
            String upiUrl = "upi://pay?pa=" + userId + "@upi&pn=" + userId + "&cu=INR&am=" + "0.00";
            ImageView qrImageView = generateQRCode(upiUrl);
            qrBox.getChildren().add(qrImageView);
        } catch (Exception e) {
            // Fallback to text-based QR
            Text qrPlaceholder = new Text("📷\nQR CODE\n" + userId + "@upi");
            qrPlaceholder.setFont(Font.font("Monospace", FontWeight.BOLD, 14));
            qrPlaceholder.setStyle("-fx-text-fill: black;");
            qrBox.getChildren().add(qrPlaceholder);
        }

        qrSection.getChildren().addAll(qrLabel, qrBox);
        return qrSection;
    }

    private ImageView generateQRCode(String qrText) throws WriterException {
        QRCodeWriter qrWriter = new QRCodeWriter();
        BitMatrix bitMatrix = qrWriter.encode(qrText, BarcodeFormat.QR_CODE, 200, 200);
        
        // Create JavaFX image directly without SwingFXUtils
        WritableImage writableImage = new WritableImage(200, 200);
        javafx.scene.image.PixelWriter pixelWriter = writableImage.getPixelWriter();
        
        for (int x = 0; x < 200; x++) {
            for (int y = 0; y < 200; y++) {
                int argb = bitMatrix.get(x, y) ? 0xFF000000 : 0xFFFFFFFF;
                pixelWriter.setArgb(x, y, argb);
            }
        }
        
        return new ImageView(writableImage);
    }

    private HBox createFooter() {
        HBox footer = new HBox(15);
        footer.setAlignment(Pos.CENTER);
        footer.setPadding(new Insets(20));

        Button shareBtn = new Button("📤 Share QR");
        shareBtn.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white; -fx-padding: 12 24; -fx-font-size: 14px; -fx-border-radius: 25; -fx-background-radius: 25;");
        shareBtn.setOnAction(e -> shareQRCode());

        Button copyLinkBtn = new Button("📋 Copy Link");
        copyLinkBtn.setStyle("-fx-background-color: #2196F3; -fx-text-fill: white; -fx-padding: 12 24; -fx-font-size: 14px; -fx-border-radius: 25; -fx-background-radius: 25;");
        copyLinkBtn.setOnAction(e -> copyPaymentLink());

        Button backBtn = new Button("↩️ Back");
        backBtn.setStyle("-fx-background-color: #FF5722; -fx-text-fill: white; -fx-padding: 12 24; -fx-font-size: 14px; -fx-border-radius: 25; -fx-background-radius: 25;");
        backBtn.setOnAction(e -> goBack());

        footer.getChildren().addAll(shareBtn, copyLinkBtn, backBtn);
        return footer;
    }

    private void shareQRCode() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Share QR Code");
        alert.setHeaderText("QR Code Sharing Options");
        alert.setContentText("In a real app, this would:\n• Save QR code to device\n• Share via WhatsApp, Email, etc.\n• Generate shareable link");
        alert.showAndWait();
    }

    private void copyPaymentLink() {
        String paymentLink = "upi://pay?pa=" + userId + "@upi&pn=" + userId + "&cu=INR";
        
        // In a real app, this would copy to clipboard
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Payment Link Copied");
        alert.setHeaderText("Link Ready to Share");
        alert.setContentText("Payment Link:\n" + paymentLink + "\n\nShare this link with the payer!");
        alert.showAndWait();
    }

    private void goBack() {
        Dashboard dashboard = new Dashboard(primaryStage, userId);
        dashboard.show();
    }

    private void showRequestDetails(String amount, String remark) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Payment Request Generated");
        alert.setHeaderText("Share this link with the payer:");
        
        String requestLink = "upi://pay?pa=" + userId + "@upi&pn=" + userId + "&am=" + 
                           (amount.equals("Any amount") ? "" : amount.replace("₹", "")) + 
                           "&tn=" + remark.replace(" ", "%20") + "&cu=INR";
        
        TextArea textArea = new TextArea(requestLink);
        textArea.setWrapText(true);
        textArea.setEditable(false);
        
        alert.getDialogPane().setContent(textArea);
        alert.showAndWait();
    }
}
