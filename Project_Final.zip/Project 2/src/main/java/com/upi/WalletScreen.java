package com.upi;

import com.upi.database.WalletRepository;
import com.upi.model.WalletCard;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.util.List;

public class WalletScreen {
    private Stage primaryStage;
    private String currentUserUpiId;

    public WalletScreen(Stage primaryStage, String currentUserUpiId) {
        this.primaryStage = primaryStage;
        this.currentUserUpiId = currentUserUpiId;
    }

    public void show() {
        VBox layout = new VBox(15);
        layout.setAlignment(Pos.CENTER);
        layout.setPadding(new Insets(25));
        layout.setStyle("-fx-background-color: #f0f8ff;");

        // Header
        Text header = new Text("💳 My Wallet");
        header.setFont(Font.font("Arial", FontWeight.BOLD, 24));
        header.setFill(Color.web("#2196F3"));
        layout.getChildren().add(header);

        // Wallet Repository
        WalletRepository walletRepo = new WalletRepository();
        List<WalletCard> cards = walletRepo.findByUserUpiId(currentUserUpiId);

        if (cards.isEmpty()) {
            Text noCardsText = new Text("No cards in wallet. Add your first card!");
            noCardsText.setFont(Font.font("Arial", 16));
            noCardsText.setFill(Color.GRAY);
            layout.getChildren().add(noCardsText);
        } else {
            // Display cards
            for (WalletCard card : cards) {
                layout.getChildren().add(createCardDisplay(card));
            }
        }

        // Add Card Button
        Button addCardBtn = new Button("➕ Add New Card");
        addCardBtn.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white; -fx-padding: 12 24; -fx-font-size: 14px; -fx-border-radius: 25; -fx-background-radius: 25;");
        addCardBtn.setPrefWidth(200);
        addCardBtn.setOnAction(e -> openAddCardScreen());

        // Back Button
        Button backBtn = new Button("⬅ Back to Dashboard");
        backBtn.setStyle("-fx-background-color: #6c757d; -fx-text-fill: white; -fx-padding: 12 24; -fx-font-size: 14px; -fx-border-radius: 25; -fx-background-radius: 25;");
        backBtn.setPrefWidth(200);
        backBtn.setOnAction(e -> new Dashboard(primaryStage, currentUserUpiId).show());

        HBox buttonBox = new HBox(15);
        buttonBox.setAlignment(Pos.CENTER);
        buttonBox.getChildren().addAll(addCardBtn, backBtn);
        layout.getChildren().add(buttonBox);

        Scene scene = new Scene(layout, 600, 700);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Smart UPI System - My Wallet");
        primaryStage.show();
    }

    private VBox createCardDisplay(WalletCard card) {
        VBox cardBox = new VBox(10);
        cardBox.setStyle("-fx-background-color: white; -fx-border-color: #e0e0e0; -fx-border-width: 1; -fx-border-radius: 10; -fx-padding: 15;");
        cardBox.setPrefWidth(550);

        // Card Header
        HBox headerBox = new HBox(10);
        headerBox.setAlignment(Pos.CENTER_LEFT);
        
        Text cardTypeLabel = new Text(card.getCardType());
        cardTypeLabel.setFont(Font.font("Arial", FontWeight.BOLD, 14));
        cardTypeLabel.setFill(card.getCardType().equals("CREDIT") ? Color.web("#FF6B6B") : Color.web("#2196F3"));
        headerBox.getChildren().add(cardTypeLabel);

        // Default Badge
        if (card.isDefault()) {
            Text defaultBadge = new Text("⭐ DEFAULT");
            defaultBadge.setFont(Font.font("Arial", FontWeight.BOLD, 10));
            defaultBadge.setFill(Color.web("#FF9800"));
            headerBox.getChildren().add(defaultBadge);
        }

        // Card Details
        VBox detailsBox = new VBox(5);
        
        Text cardNumber = new Text("🔢 " + card.getCardNumber());
        cardNumber.setFont(Font.font("Courier New", 14));
        cardNumber.setFill(Color.BLACK);
        
        Text cardHolder = new Text("👤 " + card.getCardHolderName());
        cardHolder.setFont(Font.font("Arial", 12));
        cardHolder.setFill(Color.DARKGRAY);
        
        Text expiry = new Text("📅 Expires: " + card.getFormattedExpiry());
        expiry.setFont(Font.font("Arial", 12));
        expiry.setFill(card.isExpired() ? Color.RED : Color.DARKGRAY);
        
        Text bank = new Text("🏦 " + card.getBankName());
        bank.setFont(Font.font("Arial", 12));
        bank.setFill(Color.DARKGRAY);

        detailsBox.getChildren().addAll(cardNumber, cardHolder, expiry, bank);

        // Action Buttons
        HBox actionBox = new HBox(10);
        
        if (card.isDefault()) {
            Text defaultText = new Text("  Default Payment Method");
            defaultText.setFont(Font.font("Arial", FontWeight.BOLD, 11));
            defaultText.setFill(Color.web("#4CAF50"));
            actionBox.getChildren().add(defaultText);
        }

        Button viewBtn = new Button("View");
        viewBtn.setStyle("-fx-background-color: #2196F3; -fx-text-fill: white; -fx-padding: 8 16; -fx-font-size: 12px; -fx-border-radius: 5;");
        viewBtn.setOnAction(e -> viewCardDetails(card));

        Button editBtn = new Button("Edit");
        editBtn.setStyle("-fx-background-color: #FF9800; -fx-text-fill: white; -fx-padding: 8 16; -fx-font-size: 12px; -fx-border-radius: 5;");
        editBtn.setOnAction(e -> editCard(card));

        Button removeBtn = new Button("Remove");
        removeBtn.setStyle("-fx-background-color: #f44336; -fx-text-fill: white; -fx-padding: 8 16; -fx-font-size: 12px; -fx-border-radius: 5;");
        removeBtn.setOnAction(e -> removeCard(card));

        actionBox.getChildren().addAll(viewBtn, editBtn, removeBtn);

        cardBox.getChildren().addAll(headerBox, detailsBox, actionBox);
        return cardBox;
    }

    private void openAddCardScreen() {
        AddCardScreen addCardScreen = new AddCardScreen(primaryStage, currentUserUpiId);
        addCardScreen.show();
    }

    private void viewCardDetails(WalletCard card) {
        Alert detailsDialog = new Alert(Alert.AlertType.INFORMATION);
        detailsDialog.setTitle("Card Details");
        detailsDialog.setHeaderText(card.getCardType() + " Card Details");
        
        String details = String.format(
            "Card Number: %s\n" +
            "Card Holder: %s\n" +
            "Bank Name: %s\n" +
            "Expiry Date: %s\n" +
            "Card Type: %s\n" +
            "Status: %s\n" +
            "Default Card: %s\n" +
            "Added Date: %s",
            card.getCardNumber(),
            card.getCardHolderName(),
            card.getBankName(),
            card.getFormattedExpiry(),
            card.getCardType(),
            card.isActive() ? "Active" : "Inactive",
            card.isDefault() ? "Yes" : "No",
            card.getAddedDate() != null ? card.getAddedDate().toString() : "Unknown"
        );
        
        detailsDialog.setContentText(details);
        detailsDialog.setResizable(true);
        detailsDialog.showAndWait();
    }

    private void editCard(WalletCard card) {
        EditCardScreen editCardScreen = new EditCardScreen(primaryStage, currentUserUpiId, card);
        editCardScreen.show();
    }

    private void removeCard(WalletCard card) {
        Alert confirmDialog = new Alert(Alert.AlertType.CONFIRMATION);
        confirmDialog.setTitle("Remove Card");
        confirmDialog.setHeaderText("Remove " + card.getCardType() + " Card");
        confirmDialog.setContentText("Are you sure you want to remove this card?\n\n" + card.getCardNumber() + "\n" + card.getCardHolderName());

        Button yesButton = new Button("Yes, Remove");
        Button noButton = new Button("Cancel");

        confirmDialog.getButtonTypes().setAll(ButtonType.YES, ButtonType.NO);
        yesButton = (Button) confirmDialog.getDialogPane().lookupButton(ButtonType.YES);
        noButton = (Button) confirmDialog.getDialogPane().lookupButton(ButtonType.NO);

        if (yesButton != null) {
            yesButton.setStyle("-fx-background-color: #f44336;");
        }
        if (noButton != null) {
            noButton.setStyle("-fx-background-color: #6c757d;");
        }

        confirmDialog.showAndWait().ifPresent(response -> {
            if (response == ButtonType.YES) {
                WalletRepository walletRepo = new WalletRepository();
                boolean removed = walletRepo.deleteCard(card.getCardId());
                
                if (removed) {
                    Alert successAlert = new Alert(Alert.AlertType.INFORMATION);
                    successAlert.setTitle("Card Removed");
                    successAlert.setHeaderText("Success!");
                    successAlert.setContentText("Card removed successfully from your wallet.");
                    successAlert.showAndWait();
                    
                    // Refresh wallet screen
                    show();
                } else {
                    Alert errorAlert = new Alert(Alert.AlertType.ERROR);
                    errorAlert.setTitle("Error");
                    errorAlert.setHeaderText("Failed to Remove Card");
                    errorAlert.setContentText("Could not remove card. Please try again.");
                    errorAlert.showAndWait();
                }
            }
        });
    }
}
