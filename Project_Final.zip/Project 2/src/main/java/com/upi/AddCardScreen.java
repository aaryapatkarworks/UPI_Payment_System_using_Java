package com.upi;

import com.upi.database.WalletRepository;
import com.upi.model.WalletCard;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.time.YearMonth;

public class AddCardScreen {
    private Stage primaryStage;
    private String currentUserUpiId;
    private ComboBox<String> typeComboBox;

    public AddCardScreen(Stage primaryStage, String currentUserUpiId) {
        this.primaryStage = primaryStage;
        this.currentUserUpiId = currentUserUpiId;
    }

    public void show() {
        VBox layout = new VBox(15);
        layout.setAlignment(Pos.CENTER);
        layout.setPadding(new Insets(25));
        layout.setStyle("-fx-background-color: #f0f8ff;");

        // Header
        Text header = new Text("➕ Add New Card");
        header.setFont(Font.font("Arial", FontWeight.BOLD, 24));
        header.setFill(Color.web("#2196F3"));
        layout.getChildren().add(header);

        // Form Grid
        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setStyle("-fx-background-color: white; -fx-border-color: #e0e0e0; -fx-border-width: 1; -fx-border-radius: 10; -fx-padding: 20;");
        grid.setPrefWidth(500);

        // Card Type
        Label typeLabel = new Label("Card Type:");
        grid.add(typeLabel, 0, 0);

        typeComboBox = new ComboBox<>();
        typeComboBox.getItems().addAll("DEBIT", "CREDIT");
        typeComboBox.setPromptText("Select card type");
        grid.add(typeComboBox, 1, 0);

        // Card Number
        Label numberLabel = new Label("Card Number:");
        grid.add(numberLabel, 0, 1);

        TextField numberField = new TextField();
        numberField.setPromptText("1234 5678 9012 3456");
        grid.add(numberField, 1, 1);

        // Card Holder Name
        Label holderLabel = new Label("Card Holder Name:");
        grid.add(holderLabel, 0, 2);

        TextField holderField = new TextField();
        holderField.setPromptText("Enter cardholder name");
        grid.add(holderField, 1, 2);

        // Expiry Date
        Label expiryLabel = new Label("Expiry Date:");
        grid.add(expiryLabel, 0, 3);

        HBox expiryBox = new HBox(5);
        
        ComboBox<String> monthComboBox = new ComboBox<>();
        for (int i = 1; i <= 12; i++) {
            monthComboBox.getItems().add(String.format("%02d", i));
        }
        monthComboBox.setPromptText("MM");
        monthComboBox.setPrefWidth(80);
        
        ComboBox<String> yearComboBox = new ComboBox<>();
        int currentYear = java.time.Year.now().getValue();
        for (int i = currentYear; i <= currentYear + 10; i++) {
            yearComboBox.getItems().add(String.valueOf(i));
        }
        yearComboBox.setPromptText("YYYY");
        yearComboBox.setPrefWidth(100);
        
        expiryBox.getChildren().addAll(monthComboBox, yearComboBox);
        grid.add(expiryBox, 1, 3);

        // CVV
        Label cvvLabel = new Label("CVV:");
        grid.add(cvvLabel, 0, 4);

        PasswordField cvvField = new PasswordField();
        cvvField.setPromptText("123");
        cvvField.setPrefWidth(100);
        grid.add(cvvField, 1, 4);

        // Bank Name
        Label bankLabel = new Label("Bank Name:");
        grid.add(bankLabel, 0, 5);

        TextField bankField = new TextField();
        bankField.setPromptText("Enter bank name");
        grid.add(bankField, 1, 5);

        // Default Card Checkbox
        CheckBox defaultCheckBox = new CheckBox("Set as Default Payment Method");
        defaultCheckBox.setSelected(false);
        grid.add(defaultCheckBox, 0, 6);

        // Buttons
        HBox buttonBox = new HBox(15);
        buttonBox.setAlignment(Pos.CENTER);
        buttonBox.setPadding(new Insets(20, 0, 0, 0));

        Button saveBtn = new Button("💳 Save Card");
        saveBtn.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white; -fx-padding: 12 24; -fx-font-size: 14px; -fx-border-radius: 25; -fx-background-radius: 25;");
        saveBtn.setPrefWidth(150);

        Button cancelBtn = new Button("❌ Cancel");
        cancelBtn.setStyle("-fx-background-color: #6c757d; -fx-text-fill: white; -fx-padding: 12 24; -fx-font-size: 14px; -fx-border-radius: 25; -fx-background-radius: 25;");
        cancelBtn.setPrefWidth(150);

        buttonBox.getChildren().addAll(saveBtn, cancelBtn);
        grid.add(buttonBox, 1, 7);

        // Action Target
        Text actiontarget = new Text();
        actiontarget.setStyle("-fx-font-size: 12px;");
        grid.add(actiontarget, 0, 8, 2, 1);

        layout.getChildren().add(grid);

        // Button Actions
        saveBtn.setOnAction(e -> {
            if (validateCardForm(numberField, holderField, monthComboBox, yearComboBox, cvvField, bankField, actiontarget)) {
                saveCard(numberField, holderField, monthComboBox, yearComboBox, cvvField, bankField, defaultCheckBox.isSelected(), actiontarget);
            }
        });

        cancelBtn.setOnAction(e -> {
            WalletScreen walletScreen = new WalletScreen(primaryStage, currentUserUpiId);
            walletScreen.show();
        });

        Scene scene = new Scene(layout, 550, 650);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Smart UPI System - Add Card");
        primaryStage.show();
    }

    private boolean validateCardForm(TextField numberField, TextField holderField, ComboBox<String> monthComboBox, 
                                       ComboBox<String> yearComboBox, PasswordField cvvField, TextField bankField, Text actiontarget) {
        
        // Validate Card Number (16 digits)
        String cardNumber = numberField.getText().replaceAll("\\s", "");
        if (cardNumber.length() != 16 || !cardNumber.matches("\\d+")) {
            actiontarget.setFill(Color.FIREBRICK);
            actiontarget.setText("Please enter a valid 16-digit card number");
            return false;
        }

        // Validate Holder Name
        if (holderField.getText().isEmpty() || holderField.getText().length() < 3) {
            actiontarget.setFill(Color.FIREBRICK);
            actiontarget.setText("Please enter cardholder name (min 3 characters)");
            return false;
        }

        // Validate Expiry
        if (monthComboBox.getValue() == null || yearComboBox.getValue() == null) {
            actiontarget.setFill(Color.FIREBRICK);
            actiontarget.setText("Please select expiry month and year");
            return false;
        }

        // Validate CVV (3 digits)
        String cvv = cvvField.getText();
        if (cvv.length() != 3 || !cvv.matches("\\d+")) {
            actiontarget.setFill(Color.FIREBRICK);
            actiontarget.setText("Please enter a valid 3-digit CVV");
            return false;
        }

        // Validate Bank Name
        if (bankField.getText().isEmpty() || bankField.getText().length() < 3) {
            actiontarget.setFill(Color.FIREBRICK);
            actiontarget.setText("Please enter bank name (min 3 characters)");
            return false;
        }

        // Check if card is expired
        int month = Integer.parseInt(monthComboBox.getValue());
        int year = Integer.parseInt(yearComboBox.getValue());
        YearMonth expiry = YearMonth.of(year, month);
        if (expiry.isBefore(java.time.YearMonth.now())) {
            actiontarget.setFill(Color.FIREBRICK);
            actiontarget.setText("Card has expired. Please use a valid card.");
            return false;
        }

        return true;
    }

    private void saveCard(TextField numberField, TextField holderField, ComboBox<String> monthComboBox, 
                       ComboBox<String> yearComboBox, PasswordField cvvField, TextField bankField, boolean isDefault, Text actiontarget) {
        
        try {
            WalletRepository walletRepo = new WalletRepository();
            
            WalletCard newCard = new WalletCard(
                currentUserUpiId,
                typeComboBox.getValue(),
                numberField.getText(),
                holderField.getText(),
                Integer.parseInt(monthComboBox.getValue()),
                Integer.parseInt(yearComboBox.getValue()),
                cvvField.getText(),
                bankField.getText()
            );

            newCard.setDefault(isDefault);
            
            WalletCard savedCard = walletRepo.save(newCard);
            
            actiontarget.setFill(Color.GREEN);
            actiontarget.setText("✅ Card added successfully!");
            
            // Clear form
            numberField.clear();
            holderField.clear();
            monthComboBox.setValue(null);
            yearComboBox.setValue(null);
            cvvField.clear();
            bankField.clear();
            
            // Go back to wallet after 2 seconds
            javafx.application.Platform.runLater(() -> {
                try {
                    Thread.sleep(2000);
                    WalletScreen walletScreen = new WalletScreen(primaryStage, currentUserUpiId);
                    walletScreen.show();
                } catch (InterruptedException ex) {
                    ex.printStackTrace();
                }
            });
            
        } catch (Exception e) {
            actiontarget.setFill(Color.FIREBRICK);
            actiontarget.setText("❌ Failed to save card: " + e.getMessage());
        }
    }
}
