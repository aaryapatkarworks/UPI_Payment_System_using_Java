package com.upi.model;

import java.time.LocalDateTime;

public class WalletCard {
    private String cardId;
    private String userUpiId;
    private String cardType; // DEBIT, CREDIT
    private String cardNumber;
    private String cardHolderName;
    private int expiryMonth;
    private int expiryYear;
    private String cvv;
    private String bankName;
    private boolean isDefault;
    private boolean isActive;
    private LocalDateTime addedDate;
    
    public WalletCard() {
        this.isActive = true;
        this.isDefault = false;
        this.addedDate = LocalDateTime.now();
    }
    
    public WalletCard(String userUpiId, String cardType, String cardNumber, String cardHolderName, 
                   int expiryMonth, int expiryYear, String cvv, String bankName) {
        this();
        this.cardId = java.util.UUID.randomUUID().toString();
        this.userUpiId = userUpiId;
        this.cardType = cardType;
        this.cardNumber = maskCardNumber(cardNumber);
        this.cardHolderName = cardHolderName;
        this.expiryMonth = expiryMonth;
        this.expiryYear = expiryYear;
        this.cvv = cvv;
        this.bankName = bankName;
    }
    
    private String maskCardNumber(String fullNumber) {
        if (fullNumber == null || fullNumber.length() < 4) {
            return "****";
        }
        return "**** **** **** " + fullNumber.substring(fullNumber.length() - 4);
    }
    
    public boolean isExpired() {
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime expiry = LocalDateTime.of(expiryYear, expiryMonth, 1, 0, 0);
        return now.isAfter(expiry);
    }
    
    public String getFormattedExpiry() {
        return String.format("%02d/%d", expiryMonth, expiryYear);
    }
    
    // Getters and Setters
    public String getCardId() { return cardId; }
    public void setCardId(String cardId) { this.cardId = cardId; }
    
    public String getUserUpiId() { return userUpiId; }
    public void setUserUpiId(String userUpiId) { this.userUpiId = userUpiId; }
    
    public String getCardType() { return cardType; }
    public void setCardType(String cardType) { this.cardType = cardType; }
    
    public String getCardNumber() { return cardNumber; }
    public void setCardNumber(String cardNumber) { this.cardNumber = maskCardNumber(cardNumber); }
    
    public String getCardHolderName() { return cardHolderName; }
    public void setCardHolderName(String cardHolderName) { this.cardHolderName = cardHolderName; }
    
    public int getExpiryMonth() { return expiryMonth; }
    public void setExpiryMonth(int expiryMonth) { this.expiryMonth = expiryMonth; }
    
    public int getExpiryYear() { return expiryYear; }
    public void setExpiryYear(int expiryYear) { this.expiryYear = expiryYear; }
    
    public String getCvv() { return cvv; }
    public void setCvv(String cvv) { this.cvv = cvv; }
    
    public String getBankName() { return bankName; }
    public void setBankName(String bankName) { this.bankName = bankName; }
    
    public boolean isDefault() { return isDefault; }
    public void setDefault(boolean isDefault) { this.isDefault = isDefault; }
    
    public boolean isActive() { return isActive; }
    public void setActive(boolean active) { isActive = active; }
    
    public LocalDateTime getAddedDate() { return addedDate; }
    public void setAddedDate(LocalDateTime addedDate) { this.addedDate = addedDate; }
    
    @Override
    public String toString() {
        return String.format("WalletCard{Type='%s', Bank='%s', Number='%s', Holder='%s', Expiry='%s', Default=%s}", 
                           cardType, bankName, cardNumber, cardHolderName, getFormattedExpiry(), isDefault);
    }
}
