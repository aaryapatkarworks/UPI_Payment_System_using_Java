package com.upi.model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Transaction {
    private String transactionId;
    private String fromUpiId;
    private String toUpiId;
    private double amount;
    private String type; // SENT, RECEIVED, FAILED
    private String remark;
    private LocalDateTime timestamp;
    private String status; // PENDING, COMPLETED, FAILED
    private String referenceNumber;
    private double fee;
    
    public Transaction() {
        this.timestamp = LocalDateTime.now();
        this.fee = 0.0;
        this.status = "PENDING";
        this.transactionId = generateTransactionId();
    }
    
    public Transaction(String fromUpiId, String toUpiId, double amount, String type, String remark) {
        this();
        this.fromUpiId = fromUpiId;
        this.toUpiId = toUpiId;
        this.amount = amount;
        this.type = type;
        this.remark = remark;
        this.referenceNumber = generateReferenceNumber();
    }
    
    public Transaction(String fromUpiId, String toUpiId, double amount, String type, String remark, String status) {
        this(fromUpiId, toUpiId, amount, type, remark);
        this.status = status;
    }
    
    private String generateTransactionId() {
        return "TXN" + System.currentTimeMillis() % 1000000;
    }
    
    private String generateReferenceNumber() {
        return "REF" + (System.currentTimeMillis() % 100000);
    }
    
    public String getDetails() {
        if (type.equals("SENT")) {
            return "Sent to " + toUpiId;
        } else if (type.equals("RECEIVED")) {
            return "Received from " + fromUpiId;
        } else {
            return remark != null ? remark : "Transaction";
        }
    }
    
    public String getFormattedDate() {
        return timestamp.format(DateTimeFormatter.ofPattern("MMM dd, yyyy HH:mm"));
    }
    
    // Getters and Setters
    public String getTransactionId() { return transactionId; }
    public void setTransactionId(String transactionId) { this.transactionId = transactionId; }
    
    public String getFromUpiId() { return fromUpiId; }
    public void setFromUpiId(String fromUpiId) { this.fromUpiId = fromUpiId; }
    
    public String getToUpiId() { return toUpiId; }
    public void setToUpiId(String toUpiId) { this.toUpiId = toUpiId; }
    
    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }
    
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
    
    public String getRemark() { return remark; }
    public void setRemark(String remark) { this.remark = remark; }
    
    public LocalDateTime getTimestamp() { return timestamp; }
    public void setTimestamp(LocalDateTime timestamp) { this.timestamp = timestamp; }
    
    // Database compatibility methods
    public LocalDateTime getCreatedAt() { return timestamp; }
    public void setCreatedAt(LocalDateTime createdAt) { this.timestamp = createdAt; }
    
    public LocalDateTime getUpdatedAt() { return timestamp; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.timestamp = updatedAt; }
    
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    
    public String getReferenceNumber() { return referenceNumber; }
    public void setReferenceNumber(String referenceNumber) { this.referenceNumber = referenceNumber; }
    
    public double getFee() { return fee; }
    public void setFee(double fee) { this.fee = fee; }
    
    // Business Methods
    public void completeTransaction() {
        this.status = "COMPLETED";
    }
    
    public void failTransaction() {
        this.status = "FAILED";
        this.type = "FAILED";
    }
    
    public boolean isCompleted() {
        return "COMPLETED".equals(status);
    }
    
    public boolean isFailed() {
        return "FAILED".equals(status);
    }
    
    public String getFormattedAmount() {
        return String.format("₹%.2f", amount);
    }
    
    public String getFormattedTimestamp() {
        return timestamp.format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
    }
    
    @Override
    public String toString() {
        return String.format("Transaction{ID='%s', %s %s to %s, Amount=%s, Status='%s'}", 
                           transactionId, type, fromUpiId, toUpiId, getFormattedAmount(), status);
    }
}
