package com.upi.model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class User {
    private String userId;
    private String upiId;
    private String fullName;
    private String phoneNumber;
    private String email;
    private String pin;
    private String bankName;
    private String accountNumber;
    private String panNumber;
    private String aadhaarNumber;
    private double balance;
    private LocalDateTime registrationDate;
    private LocalDateTime lastLogin;
    private List<String> linkedAccounts;
    private boolean isActive;
    private String profileStatus;
    private String kycStatus;
    private String accountType;
    
    public User() {
        this.linkedAccounts = new ArrayList<>();
        this.isActive = true;
        this.profileStatus = "VERIFIED";
        this.registrationDate = LocalDateTime.now();
        this.balance = 10000.00; // Default balance for demo
    }
    
    public User(String fullName, String phoneNumber, String email, String pin, String bankName) {
        this();
        this.fullName = fullName;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.pin = pin;
        this.bankName = bankName;
        this.userId = generateUserId();
        this.upiId = generateUpiId(fullName);
        this.accountNumber = generateAccountNumber();
    }
    
    private String generateUserId() {
        return "USER" + System.currentTimeMillis() % 100000;
    }
    
    private String generateUpiId(String fullName) {
        String baseName = fullName.toLowerCase().replaceAll("\\s+", "");
        return baseName + (System.currentTimeMillis() % 1000) + "@upi";
    }
    
    private String generateAccountNumber() {
        return "XXXX" + (System.currentTimeMillis() % 10000);
    }
    
    // Getters and Setters
    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }
    
    public String getUpiId() { return upiId; }
    public void setUpiId(String upiId) { this.upiId = upiId; }
    
    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }
    
    public String getPhoneNumber() { return phoneNumber; }
    public void setPhoneNumber(String phoneNumber) { this.phoneNumber = phoneNumber; }
    
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    
    public String getPin() { return pin; }
    public void setPin(String pin) { this.pin = pin; }
    
    public String getBankName() { return bankName; }
    public void setBankName(String bankName) { this.bankName = bankName; }
    
    public String getAccountNumber() { return accountNumber; }
    public void setAccountNumber(String accountNumber) { this.accountNumber = accountNumber; }
    
    public double getBalance() { return balance; }
    public void setBalance(double balance) { this.balance = balance; }
    
    public LocalDateTime getRegistrationDate() { return registrationDate; }
    public void setRegistrationDate(LocalDateTime registrationDate) { this.registrationDate = registrationDate; }
    
    public LocalDateTime getLastLogin() { return lastLogin; }
    public void setLastLogin(LocalDateTime lastLogin) { this.lastLogin = lastLogin; }
    
    public List<String> getLinkedAccounts() { return linkedAccounts; }
    public void setLinkedAccounts(List<String> linkedAccounts) { this.linkedAccounts = linkedAccounts; }
    
    public boolean isActive() { return isActive; }
    public void setActive(boolean active) { isActive = active; }
    
    public String getProfileStatus() { return profileStatus; }
    public void setProfileStatus(String profileStatus) { this.profileStatus = profileStatus; }
    
    public String getPanNumber() { return panNumber; }
    public void setPanNumber(String panNumber) { this.panNumber = panNumber; }
    
    public String getAadhaarNumber() { return aadhaarNumber; }
    public void setAadhaarNumber(String aadhaarNumber) { this.aadhaarNumber = aadhaarNumber; }
    
    public String getKycStatus() { return kycStatus; }
    public void setKycStatus(String kycStatus) { this.kycStatus = kycStatus; }
    
    public String getAccountType() { return accountType; }
    public void setAccountType(String accountType) { this.accountType = accountType; }
    
    // Business Methods
    public boolean validatePin(String inputPin) {
        return this.pin.equals(inputPin);
    }
    
    public boolean updateBalance(double amount) {
        if (this.balance + amount >= 0) {
            this.balance += amount;
            return true;
        }
        return false;
    }
    
    public void addLinkedAccount(String account) {
        if (!linkedAccounts.contains(account)) {
            linkedAccounts.add(account);
        }
    }
    
    public void removeLinkedAccount(String account) {
        linkedAccounts.remove(account);
    }
    
    @Override
    public String toString() {
        return String.format("User{UPI ID='%s', Name='%s', Balance=₹%.2f, Status='%s'}", 
                           upiId, fullName, balance, profileStatus);
    }
}
