package com.upi;

import com.upi.database.TransactionRepository;
import com.upi.model.Transaction;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.util.Duration;
import java.util.List;

public class TransactionHistory {
    private Stage primaryStage;
    private String userId;

    public TransactionHistory(Stage primaryStage, String userId) {
        this.primaryStage = primaryStage;
        this.userId = userId;
    }

    public void show() {
        VBox root = new VBox(20);
        root.setPadding(new Insets(20));
        root.setStyle("-fx-background-color: #f5f5f5;");

        // Header
        VBox header = new VBox(10);
        header.setAlignment(Pos.CENTER);
        header.setStyle("-fx-background-color: #2196F3; -fx-padding: 15; -fx-background-radius: 10;");

        Text title = new Text("Transaction History");
        title.setFont(Font.font("Arial", FontWeight.BOLD, 20));
        title.setFill(Color.WHITE);

        Text subtitle = new Text("Account: " + userId + "@upi");
        subtitle.setFont(Font.font("Arial", FontWeight.NORMAL, 14));
        subtitle.setFill(Color.WHITE);

        header.getChildren().addAll(title, subtitle);
        root.getChildren().add(header);

        // Filter Section
        HBox filterSection = createFilterSection();
        root.getChildren().add(filterSection);

        // Transaction List
        ListView<Transaction> transactionList = createTransactionList();
        root.getChildren().add(transactionList);

        // Summary Section
        VBox summarySection = createSummarySection();
        root.getChildren().add(summarySection);

        // Back Button
        Button backBtn = new Button("Back to Dashboard");
        backBtn.setStyle("-fx-background-color: #f44336; -fx-text-fill: white; -fx-padding: 10 20; -fx-font-size: 14px;");
        backBtn.setAlignment(Pos.CENTER);
        backBtn.setOnAction(e -> {
            Dashboard dashboard = new Dashboard(primaryStage, userId);
            dashboard.show();
        });

        root.getChildren().add(backBtn);

        Scene scene = new Scene(root, 600, 700);

        // Initial load
        refreshTransactionList("All Transactions", "All Time");
        
        // Set up auto-refresh every 5 seconds
        Timeline timeline = new Timeline(
            new KeyFrame(
                Duration.seconds(5),
                event -> refreshTransactionList("All Transactions", "All Time")
            )
        );
        timeline.setCycleCount(Timeline.INDEFINITE);
        timeline.play();
        
        primaryStage.setScene(scene);
        primaryStage.setTitle("Transaction History - " + userId);
        primaryStage.show();
    }

    private HBox createFilterSection() {
        HBox filterSection = new HBox(10);
        filterSection.setAlignment(Pos.CENTER);

        ComboBox<String> filterType = new ComboBox<>();
        filterType.getItems().addAll("All Transactions", "Sent", "Received", "Failed");
        filterType.setValue("All Transactions");

        ComboBox<String> timeFilter = new ComboBox<>();
        timeFilter.getItems().addAll("Today", "This Week", "This Month", "All Time");
        timeFilter.setValue("All Time");

        Button applyFilterBtn = new Button("Apply Filter");
        applyFilterBtn.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white; -fx-padding: 8 16;");
        applyFilterBtn.setOnAction(e -> refreshTransactionList(filterType.getValue(), timeFilter.getValue()));

        filterSection.getChildren().addAll(new Label("Filter:"), filterType, timeFilter, applyFilterBtn);
        return filterSection;
    }

    private ListView<Transaction> transactionList;

    private ListView<Transaction> createTransactionList() {
        transactionList = new ListView<>();
        transactionList.setPrefHeight(400);

        // Load transactions from database
        refreshTransactionList("All Transactions", "All Time");

        // Custom cell factory for better display
        transactionList.setCellFactory(param -> new ListCell<Transaction>() {
            @Override
            protected void updateItem(Transaction transaction, boolean empty) {
                super.updateItem(transaction, empty);
                if (empty || transaction == null) {
                    setGraphic(null);
                    setText(null);
                } else {
                    VBox vbox = new VBox(5);
                    vbox.setStyle("-fx-padding: 10; -fx-background-color: white; -fx-border-radius: 5; -fx-background-radius: 5;");
                    
                    // Determine transaction type based on user's perspective
                    String transactionType;
                    Color typeColor;
                    String transactionDetails;
                    
                    if (transaction.getFromUpiId().equals(userId)) {
                        // User is the sender
                        transactionType = "SENT";
                        typeColor = Color.RED;
                        transactionDetails = "Sent to " + transaction.getToUpiId();
                    } else {
                        // User is the receiver
                        transactionType = "RECEIVED";
                        typeColor = Color.GREEN;
                        transactionDetails = "Received from " + transaction.getFromUpiId();
                    }
                    
                    Text typeText = new Text(transactionType + " " + transaction.getAmount());
                    typeText.setFont(Font.font("Arial", FontWeight.BOLD, 14));
                    typeText.setFill(typeColor);
                    
                    Text detailsText = new Text(transactionDetails);
                    detailsText.setFont(Font.font("Arial", FontWeight.NORMAL, 12));
                    detailsText.setFill(Color.GRAY);
                    
                    Text dateText = new Text(transaction.getFormattedDate());
                    dateText.setFont(Font.font("Arial", FontWeight.NORMAL, 10));
                    dateText.setFill(Color.DARKGRAY);
                    
                    vbox.getChildren().addAll(typeText, detailsText, dateText);
                    setGraphic(vbox);
                }
            }
        });

        return transactionList;
    }

    private void refreshTransactionList(String filterType, String timeFilter) {
        try {
            TransactionRepository transactionRepo = new TransactionRepository();
            List<Transaction> transactions = transactionRepo.findByUserUpiIdWithFilters(userId, 
                filterType.equals("All Transactions") ? null : filterType.equals("Sent") ? "SENT" : filterType.equals("Received") ? "RECEIVED" : "FAILED",
                "COMPLETED", 
                50);
            
            // Clear and update the transaction list
            transactionList.getItems().clear();
            for (Transaction transaction : transactions) {
                transactionList.getItems().add(transaction);
            }
            
            // Update summary
            updateSummarySection(transactions);
            
        } catch (Exception e) {
            System.err.println("Error loading transactions: " + e.getMessage());
        }
    }

    private VBox createSummarySection() {
        VBox summarySection = new VBox(10);
        summarySection.setStyle("-fx-background-color: white; -fx-padding: 15; -fx-border-radius: 10; -fx-background-radius: 10;");

        Text summaryTitle = new Text("Summary");
        summaryTitle.setFont(Font.font("Arial", FontWeight.BOLD, 16));

        // Load real summary from database
        try {
            TransactionRepository transactionRepo = new TransactionRepository();
            List<Transaction> transactions = transactionRepo.findByUserUpiIdWithFilters(userId, null, "COMPLETED", 50);
            
            double totalSent = 0;
            double totalReceived = 0;
            
            for (Transaction transaction : transactions) {
                if (transaction.getType().equals("SENT")) {
                    totalSent += transaction.getAmount();
                } else if (transaction.getType().equals("RECEIVED")) {
                    totalReceived += transaction.getAmount();
                }
            }
            
            double netBalance = totalReceived - totalSent;
            
            HBox summaryRow1 = new HBox(20);
            summaryRow1.setAlignment(Pos.CENTER);
            
            Text totalSentText = new Text("Total Sent: ₹" + String.format("%.2f", totalSent));
            totalSentText.setFill(Color.RED);
            
            Text totalReceivedText = new Text("Total Received: ₹" + String.format("%.2f", totalReceived));
            totalReceivedText.setFill(Color.GREEN);
            
            summaryRow1.getChildren().addAll(totalSentText, totalReceivedText);
            
            HBox summaryRow2 = new HBox(20);
            summaryRow2.setAlignment(Pos.CENTER);
            
            Text netBalanceText = new Text("Net Balance: ₹" + String.format("%.2f", netBalance));
            netBalanceText.setFill(Color.BLUE);
            netBalanceText.setFont(Font.font("Arial", FontWeight.BOLD, 14));
            
            summaryRow2.getChildren().add(netBalanceText);
            
            summarySection.getChildren().addAll(summaryTitle, summaryRow1, summaryRow2);
            
        } catch (Exception e) {
            Text errorText = new Text("Error loading summary");
            errorText.setFill(Color.RED);
            summarySection.getChildren().addAll(summaryTitle, errorText);
        }
        
        return summarySection;
    }

    private void updateSummarySection(List<Transaction> transactions) {
        // This method updates the summary section with new transaction data
        // Implementation would refresh the summary display
    }
}
