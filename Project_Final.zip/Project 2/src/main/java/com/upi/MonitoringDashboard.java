package com.upi;

import com.upi.service.MonitoringService;
import com.upi.service.UserService;
import com.upi.service.PaymentService;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

public class MonitoringDashboard {
    private Stage primaryStage;
    private String userId;
    private MonitoringService monitoringService;
    private UserService userService;
    private PaymentService paymentService;
    private Timer updateTimer;
    
    // UI Components
    private Label cpuUsageLabel;
    private Label memoryUsageLabel;
    private Label activeUsersLabel;
    private Label transactionRateLabel;
    private Label responseTimeLabel;
    private Label totalTransactionsLabel;
    private Label successRateLabel;
    private Label systemHealthLabel;
    private Label systemUptimeLabel;
    private ListView<String> performanceLogList;
    
    public MonitoringDashboard(Stage primaryStage, String userId) {
        this.primaryStage = primaryStage;
        this.userId = userId;
        this.monitoringService = MonitoringService.getInstance();
        this.userService = UserService.getInstance();
        this.paymentService = PaymentService.getInstance();
    }
    
    public void show() {
        BorderPane root = new BorderPane();
        root.setStyle("-fx-background-color: #f5f5f5;");

        // Header
        VBox header = createHeader();
        root.setTop(header);

        // Main content
        VBox mainContent = createMainContent();
        root.setCenter(mainContent);

        // Footer
        HBox footer = createFooter();
        root.setBottom(footer);

        Scene scene = new Scene(root, 1000, 700);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Smart UPI System - Monitoring Dashboard");
        
        // Start real-time updates
        startRealTimeUpdates();
        
        // Stop updates when window is closed
        primaryStage.setOnCloseRequest(e -> stopRealTimeUpdates());
    }
    
    private VBox createHeader() {
        VBox header = new VBox(10);
        header.setStyle("-fx-background-color: #FF5722; -fx-padding: 15;");
        header.setAlignment(Pos.CENTER);

        Text title = new Text("System Monitoring Dashboard");
        title.setFont(Font.font("Arial", FontWeight.BOLD, 24));
        title.setFill(Color.WHITE);

        Text subtitle = new Text("Real-time System Performance Analytics");
        subtitle.setFont(Font.font("Arial", FontWeight.NORMAL, 14));
        subtitle.setFill(Color.WHITE);

        header.getChildren().addAll(title, subtitle);
        return header;
    }
    
    private VBox createMainContent() {
        VBox mainContent = new VBox(20);
        mainContent.setPadding(new Insets(20));
        
        // System Metrics Grid
        GridPane metricsGrid = createMetricsGrid();
        mainContent.getChildren().add(metricsGrid);
        
        // Performance Logs
        VBox performanceSection = createPerformanceSection();
        mainContent.getChildren().add(performanceSection);
        
        return mainContent;
    }
    
    private GridPane createMetricsGrid() {
        GridPane grid = new GridPane();
        grid.setHgap(15);
        grid.setVgap(15);
        grid.setPadding(new Insets(15));
        grid.setStyle("-fx-background-color: white; -fx-border-radius: 10; -fx-background-radius: 10;");
        
        // Title
        Text title = new Text("System Metrics");
        title.setFont(Font.font("Arial", FontWeight.BOLD, 18));
        grid.add(title, 0, 0, 3, 1);
        
        // CPU Usage
        VBox cpuBox = createMetricBox("CPU Usage", "#2196F3");
        cpuUsageLabel = (Label) cpuBox.getChildren().get(1);
        grid.add(cpuBox, 0, 1);
        
        // Memory Usage
        VBox memoryBox = createMetricBox("Memory Usage", "#4CAF50");
        memoryUsageLabel = (Label) memoryBox.getChildren().get(1);
        grid.add(memoryBox, 1, 1);
        
        // Active Users
        VBox usersBox = createMetricBox("Active Users", "#FF9800");
        activeUsersLabel = (Label) usersBox.getChildren().get(1);
        grid.add(usersBox, 2, 1);
        
        // Transaction Rate
        VBox txnRateBox = createMetricBox("Transaction Rate", "#9C27B0");
        transactionRateLabel = (Label) txnRateBox.getChildren().get(1);
        grid.add(txnRateBox, 0, 2);
        
        // Response Time
        VBox responseBox = createMetricBox("Response Time", "#F44336");
        responseTimeLabel = (Label) responseBox.getChildren().get(1);
        grid.add(responseBox, 1, 2);
        
        // System Health
        VBox healthBox = createMetricBox("System Health", "#607D8B");
        systemHealthLabel = (Label) healthBox.getChildren().get(1);
        grid.add(healthBox, 2, 2);
        
        // Total Transactions
        VBox totalTxnBox = createMetricBox("Total Transactions", "#795548");
        totalTransactionsLabel = (Label) totalTxnBox.getChildren().get(1);
        grid.add(totalTxnBox, 0, 3);
        
        // Success Rate
        VBox successBox = createMetricBox("Success Rate", "#009688");
        successRateLabel = (Label) successBox.getChildren().get(1);
        grid.add(successBox, 1, 3);
        
        // System Uptime
        VBox uptimeBox = createMetricBox("System Uptime", "#3F51B5");
        systemUptimeLabel = (Label) uptimeBox.getChildren().get(1);
        grid.add(uptimeBox, 2, 3);
        
        return grid;
    }
    
    private VBox createMetricBox(String title, String color) {
        VBox box = new VBox(5);
        box.setStyle("-fx-background-color: white; -fx-border: 2px solid " + color + "; -fx-padding: 15; -fx-border-radius: 8; -fx-background-radius: 8;");
        box.setAlignment(Pos.CENTER);
        box.setPrefSize(150, 100);
        
        Text titleLabel = new Text(title);
        titleLabel.setFont(Font.font("Arial", FontWeight.BOLD, 12));
        titleLabel.setStyle("-fx-fill: " + color + ";");
        
        Label valueLabel = new Label("--");
        valueLabel.setFont(Font.font("Arial", FontWeight.BOLD, 20));
        valueLabel.setStyle("-fx-fill: " + color + ";");
        
        box.getChildren().addAll(titleLabel, valueLabel);
        return box;
    }
    
    private VBox createPerformanceSection() {
        VBox section = new VBox(10);
        section.setStyle("-fx-background-color: white; -fx-padding: 15; -fx-border-radius: 10; -fx-background-radius: 10;");
        
        Text title = new Text("Recent Performance Logs");
        title.setFont(Font.font("Arial", FontWeight.BOLD, 16));
        section.getChildren().add(title);
        
        performanceLogList = new ListView<>();
        performanceLogList.setPrefHeight(150);
        performanceLogList.setStyle("-fx-font-family: monospace; -fx-font-size: 12px;");
        
        section.getChildren().add(performanceLogList);
        
        return section;
    }
    
    private HBox createFooter() {
        HBox footer = new HBox(20);
        footer.setStyle("-fx-background-color: #333; -fx-padding: 10;");
        footer.setAlignment(Pos.CENTER);

        Button refreshBtn = new Button("Refresh Now");
        refreshBtn.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white; -fx-padding: 8 16;");
        refreshBtn.setOnAction(e -> updateMetrics());
        
        Button generateReportBtn = new Button("Generate Report");
        generateReportBtn.setStyle("-fx-background-color: #2196F3; -fx-text-fill: white; -fx-padding: 8 16;");
        generateReportBtn.setOnAction(e -> {
            monitoringService.generateReport();
            showAlert("Report Generated", "System performance report has been generated and logged to console.");
        });
        
        Button backBtn = new Button("Back to Dashboard");
        backBtn.setStyle("-fx-background-color: #f44336; -fx-text-fill: white; -fx-padding: 8 16;");
        backBtn.setOnAction(e -> {
            stopRealTimeUpdates();
            // Go back to main dashboard (you'll need to implement this)
            showAlert("Navigation", "This would return to the main dashboard.");
        });

        footer.getChildren().addAll(refreshBtn, generateReportBtn, backBtn);
        return footer;
    }
    
    private void startRealTimeUpdates() {
        updateTimer = new Timer("MonitoringUpdateTimer", true);
        TimerTask updateTask = new TimerTask() {
            @Override
            public void run() {
                Platform.runLater(() -> updateMetrics());
            }
        };
        
        // Update every 2 seconds
        updateTimer.scheduleAtFixedRate(updateTask, 0, 2000);
    }
    
    private void stopRealTimeUpdates() {
        if (updateTimer != null) {
            updateTimer.cancel();
            updateTimer = null;
        }
    }
    
    private void updateMetrics() {
        try {
            // Get current metrics
            Map<String, MonitoringService.SystemMetrics> metrics = monitoringService.getCurrentMetrics();
            MonitoringService.SystemAnalytics analytics = monitoringService.getSystemAnalytics();
            
            // Update metric labels
            cpuUsageLabel.setText(String.format("%.1f%%", metrics.get("CPU_USAGE").getValue()));
            memoryUsageLabel.setText(String.format("%.1f%%", metrics.get("MEMORY_USAGE").getValue()));
            activeUsersLabel.setText(String.format("%.0f", metrics.get("ACTIVE_USERS").getValue()));
            transactionRateLabel.setText(String.format("%.2f/s", metrics.get("TRANSACTION_RATE").getValue()));
            responseTimeLabel.setText(String.format("%.0fms", metrics.get("RESPONSE_TIME").getValue()));
            
            // Update analytics labels
            Object totalTxObj = analytics.getMetrics().get("Total Transactions");
            Object successRateObj = analytics.getMetrics().get("Success Rate");
            Object systemHealthObj = analytics.getMetrics().get("System Health");
            Object systemUptimeObj = analytics.getMetrics().get("System Uptime");
            
            if (totalTxObj instanceof Number) {
                totalTransactionsLabel.setText(String.format("%.0f", ((Number) totalTxObj).doubleValue()));
            } else {
                totalTransactionsLabel.setText("0");
            }
            
            if (successRateObj instanceof Number) {
                successRateLabel.setText(String.format("%.1f%%", ((Number) successRateObj).doubleValue()));
            } else {
                successRateLabel.setText("0.0%");
            }
            
            if (systemHealthObj instanceof String) {
                systemHealthLabel.setText((String) systemHealthObj);
            } else {
                systemHealthLabel.setText("UNKNOWN");
            }
            
            if (systemUptimeObj instanceof String) {
                systemUptimeLabel.setText((String) systemUptimeObj);
            } else {
                systemUptimeLabel.setText("0 hours 0 minutes");
            }
            
            // Update system health color
            String health = (String) analytics.getMetrics().get("System Health");
            Color healthColor = getHealthColor(health);
            systemHealthLabel.setTextFill(healthColor);
            
            // Update performance logs
            updatePerformanceLogs();
            
        } catch (Exception e) {
            System.err.println("Error updating metrics: " + e.getMessage());
        }
    }
    
    private void updatePerformanceLogs() {
        performanceLogList.getItems().clear();
        var logs = monitoringService.getRecentPerformanceLogs(10);
        
        for (var log : logs) {
            performanceLogList.getItems().add(log.toString());
        }
    }
    
    private Color getHealthColor(String health) {
        switch (health) {
            case "HEALTHY": return Color.GREEN;
            case "WARNING": return Color.ORANGE;
            case "CRITICAL": return Color.RED;
            default: return Color.GRAY;
        }
    }
    
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
