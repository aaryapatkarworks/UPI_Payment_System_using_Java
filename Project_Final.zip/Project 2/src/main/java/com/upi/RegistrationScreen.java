package com.upi;

import com.upi.model.User;
import com.upi.service.UserService;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class RegistrationScreen {
    private Stage primaryStage;

    public RegistrationScreen(Stage primaryStage) {
        this.primaryStage = primaryStage;
    }

    public void show() {
        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(25, 25, 25, 25));
        grid.setStyle("-fx-background-color: #f0f8ff;");

        Text scenetitle = new Text("Create New UPI Account");
        scenetitle.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));
        grid.add(scenetitle, 0, 0, 2, 1);

        Label nameLabel = new Label("Full Name:");
        grid.add(nameLabel, 0, 1);

        TextField nameField = new TextField();
        nameField.setPromptText("Enter your full name");
        grid.add(nameField, 1, 1);

        Label phoneLabel = new Label("Mobile Number:");
        grid.add(phoneLabel, 0, 2);

        TextField phoneField = new TextField();
        phoneField.setPromptText("Enter 10-digit mobile number");
        grid.add(phoneField, 1, 2);

        Label emailLabel = new Label("Email:");
        grid.add(emailLabel, 0, 3);

        TextField emailField = new TextField();
        emailField.setPromptText("Enter your email address");
        grid.add(emailField, 1, 3);

        Label upiLabel = new Label("UPI ID (Auto-generated):");
        grid.add(upiLabel, 0, 4);

        TextField upiField = new TextField();
        upiField.setPromptText("System will generate UPI ID automatically");
        upiField.setEditable(false); // Make it read-only
        upiField.setStyle("-fx-background-color: #f0f0f0; -fx-text-fill: #666;");
        grid.add(upiField, 1, 4);

        Label bankLabel = new Label("Bank Account:");
        grid.add(bankLabel, 0, 5);

        ComboBox<String> bankComboBox = new ComboBox<>();
        bankComboBox.getItems().addAll(
            "State Bank of India",
            "HDFC Bank",
            "ICICI Bank",
            "Axis Bank",
            "Punjab National Bank"
        );
        bankComboBox.setPromptText("Select your bank");
        grid.add(bankComboBox, 1, 5);

        Label panLabel = new Label("PAN Card Number:");
        grid.add(panLabel, 0, 6);

        TextField panField = new TextField();
        panField.setPromptText("Enter 10-digit PAN number");
        grid.add(panField, 1, 6);

        Label aadhaarLabel = new Label("Aadhaar Number:");
        grid.add(aadhaarLabel, 0, 7);

        TextField aadhaarField = new TextField();
        aadhaarField.setPromptText("Enter 12-digit Aadhaar number");
        grid.add(aadhaarField, 1, 7);

        Label accountTypeLabel = new Label("Account Type:");
        grid.add(accountTypeLabel, 0, 8);

        ComboBox<String> accountTypeComboBox = new ComboBox<>();
        accountTypeComboBox.getItems().addAll("SAVINGS", "CURRENT", "FIXED DEPOSIT");
        accountTypeComboBox.setPromptText("Select account type");
        grid.add(accountTypeComboBox, 1, 8);

        Label pinLabel = new Label("Set 4-digit PIN:");
        grid.add(pinLabel, 0, 9);

        PasswordField pinField = new PasswordField();
        pinField.setPromptText("Enter 4-digit PIN");
        grid.add(pinField, 1, 9);

        Label confirmPinLabel = new Label("Confirm PIN:");
        grid.add(confirmPinLabel, 0, 10);

        PasswordField confirmPinField = new PasswordField();
        confirmPinField.setPromptText("Re-enter 4-digit PIN");
        grid.add(confirmPinField, 1, 10);

        Label initialBalanceLabel = new Label("Initial Balance:");
        grid.add(initialBalanceLabel, 0, 11);

        TextField initialBalanceField = new TextField();
        initialBalanceField.setPromptText("Enter initial amount (₹)");
        grid.add(initialBalanceField, 1, 11);

        Button registerBtn = new Button("Register");
        Button cancelBtn = new Button("Cancel");

        HBox hbBtn = new HBox(10);
        hbBtn.setAlignment(Pos.BOTTOM_RIGHT);
        hbBtn.getChildren().addAll(registerBtn, cancelBtn);
        grid.add(hbBtn, 1, 12);

        final Text actiontarget = new Text();
        grid.add(actiontarget, 0, 13, 2, 1);

        registerBtn.setOnAction(e -> {
            if (validateRegistration(nameField, phoneField, emailField, bankComboBox, 
                                       panField, aadhaarField, accountTypeComboBox, pinField, confirmPinField, initialBalanceField, actiontarget)) {
                
                // Get initial balance from user input
                double initialBalance = 0.0;
                try {
                    String balanceText = initialBalanceField.getText().trim();
                    if (!balanceText.isEmpty()) {
                        initialBalance = Double.parseDouble(balanceText);
                        if (initialBalance < 0) {
                            actiontarget.setFill(Color.FIREBRICK);
                            actiontarget.setText("Initial balance cannot be negative!");
                            return;
                        }
                    }
                } catch (NumberFormatException ex) {
                    actiontarget.setFill(Color.FIREBRICK);
                    actiontarget.setText("Please enter a valid initial balance!");
                    return;
                }
                
                // Create new user and save to database
                User newUser = new User(
                    nameField.getText(),
                    phoneField.getText(),
                    emailField.getText(),
                    pinField.getText(),
                    bankComboBox.getValue()
                );
                
                // Set additional fields (UPI ID will be generated automatically)
                newUser.setPanNumber(panField.getText());
                newUser.setAadhaarNumber(aadhaarField.getText());
                newUser.setAccountType(accountTypeComboBox.getValue());
                newUser.setBalance(initialBalance); // Set user-defined initial balance
                
                try {
                    UserService userService = UserService.getInstance();
                    User registeredUser = userService.registerUser(newUser);
                    
                    if (registeredUser != null) {
                        // Display the auto-generated UPI ID
                        upiField.setText(registeredUser.getUpiId());
                        actiontarget.setFill(Color.GREEN);
                        actiontarget.setText("Registration successful! Your UPI ID: " + registeredUser.getUpiId());
                        
                        // Go back to login after 2 seconds
                        javafx.application.Platform.runLater(() -> {
                            try {
                                Thread.sleep(2000);
                                new Main().start(primaryStage);
                            } catch (InterruptedException ex) {
                                ex.printStackTrace();
                            }
                        });
                    } else {
                        actiontarget.setFill(Color.FIREBRICK);
                        actiontarget.setText("Registration failed! UPI ID might already exist.");
                    }
                } catch (Exception ex) {
                    actiontarget.setFill(Color.FIREBRICK);
                    actiontarget.setText("Registration error: " + ex.getMessage());
                    ex.printStackTrace();
                }
            }
        });

        cancelBtn.setOnAction(e -> {
            new Main().start(primaryStage);
        });

        Scene scene = new Scene(grid, 500, 600);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Smart UPI System - Registration");
        primaryStage.show();
    }

    private boolean validateRegistration(TextField nameField, TextField phoneField, TextField emailField, 
                                        ComboBox<String> bankComboBox,
                                        TextField panField, TextField aadhaarField, ComboBox<String> accountTypeComboBox,
                                        PasswordField pinField, PasswordField confirmPinField, TextField initialBalanceField, Text actiontarget) {
        
        if (nameField.getText().isEmpty()) {
            actiontarget.setFill(Color.FIREBRICK);
            actiontarget.setText("Please enter your name");
            return false;
        }
        
        if (phoneField.getText().isEmpty()) {
            actiontarget.setFill(Color.FIREBRICK);
            actiontarget.setText("Please enter your phone number");
            return false;
        }
        
        if (!phoneField.getText().matches("\\d{10}")) {
            actiontarget.setFill(Color.FIREBRICK);
            actiontarget.setText("Please enter a valid 10-digit phone number");
            return false;
        }
        
        if (emailField.getText().isEmpty()) {
            actiontarget.setFill(Color.FIREBRICK);
            actiontarget.setText("Please enter your email");
            return false;
        }
        
        if (!emailField.getText().contains("@")) {
            actiontarget.setFill(Color.FIREBRICK);
            actiontarget.setText("Please enter a valid email address");
            return false;
        }
        
        if (bankComboBox.getValue() == null) {
            actiontarget.setFill(Color.FIREBRICK);
            actiontarget.setText("Please select a bank");
            return false;
        }
        
        if (panField.getText().isEmpty()) {
            actiontarget.setFill(Color.FIREBRICK);
            actiontarget.setText("Please enter your PAN card number");
            return false;
        }
        
        if (!panField.getText().matches("[A-Z]{5}[0-9]{4}[A-Z]{1}")) {
            actiontarget.setFill(Color.FIREBRICK);
            actiontarget.setText("Please enter a valid PAN card number (e.g., ABCDE1234F)");
            return false;
        }
        
        if (aadhaarField.getText().isEmpty()) {
            actiontarget.setFill(Color.FIREBRICK);
            actiontarget.setText("Please enter your Aadhaar card number");
            return false;
        }
        
        if (!aadhaarField.getText().matches("\\d{12}")) {
            actiontarget.setFill(Color.FIREBRICK);
            actiontarget.setText("Please enter a valid 12-digit Aadhaar number");
            return false;
        }
        
        if (accountTypeComboBox.getValue() == null) {
            actiontarget.setFill(Color.FIREBRICK);
            actiontarget.setText("Please select an account type");
            return false;
        }
        
        if (pinField.getText().isEmpty()) {
            actiontarget.setFill(Color.FIREBRICK);
            actiontarget.setText("Please enter a 4-digit PIN");
            return false;
        }
        
        if (!pinField.getText().matches("\\d{4}")) {
            actiontarget.setFill(Color.FIREBRICK);
            actiontarget.setText("PIN must be exactly 4 digits");
            return false;
        }
        
        if (!pinField.getText().equals(confirmPinField.getText())) {
            actiontarget.setFill(Color.FIREBRICK);
            actiontarget.setText("PINs do not match");
            return false;
        }
        
        // Validate initial balance
        String balanceText = initialBalanceField.getText().trim();
        if (!balanceText.isEmpty()) {
            try {
                double balance = Double.parseDouble(balanceText);
                if (balance < 0) {
                    actiontarget.setFill(Color.FIREBRICK);
                    actiontarget.setText("Initial balance cannot be negative");
                    return false;
                }
                if (balance > 10000000) { // 1 crore limit
                    actiontarget.setFill(Color.FIREBRICK);
                    actiontarget.setText("Initial balance cannot exceed ₹1,00,00,000");
                    return false;
                }
            } catch (NumberFormatException e) {
                actiontarget.setFill(Color.FIREBRICK);
                actiontarget.setText("Please enter a valid initial balance");
                return false;
            }
        }
        
        return true;
    }
}
