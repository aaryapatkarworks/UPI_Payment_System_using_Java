import docx
from docx.shared import Inches, Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.style import WD_STYLE_TYPE
from datetime import datetime

def create_project_report():
    # Create a new document
    doc = docx.Document()
    
    # Set default font
    style = doc.styles['Normal']
    font = style.font
    font.name = 'Times New Roman'
    font.size = Pt(12)
    
    # Title Page
    title_para = doc.add_paragraph()
    title_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    title_run = title_para.add_run('MINIPROJECT REPORT_MPJ')
    title_run.bold = True
    title_run.font.size = Pt(16)
    
    doc.add_paragraph()  # Space
    
    # Project details
    details = [
        'Project Title: Smart UPI System',
        'Student Name(s): Pranav More',
        'Enrollment/ID: [Your Enrollment ID]',
        'Course / Department: Computer Engineering',
        'Institution Name: [Your Institution Name]',
        'Guide Name: [Guide Name]',
        'Submission Date: ' + datetime.now().strftime('%d-%m-%Y')
    ]
    
    for detail in details:
        doc.add_paragraph(detail)
    
    doc.add_page_break()
    
    # Certificate
    cert_para = doc.add_paragraph()
    cert_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    cert_run = cert_para.add_run('Certificate')
    cert_run.bold = True
    cert_run.font.size = Pt(14)
    
    doc.add_paragraph()
    doc.add_paragraph('This is to certify that the project titled "Smart UPI System" is successfully completed by Pranav More under my guidance as part of the Mini Project in Java (MPJ) course. The project demonstrates a comprehensive understanding of Java programming, database design, and modern GUI development using JavaFX.')
    
    doc.add_paragraph()
    doc.add_paragraph('The project successfully implements a complete UPI payment system with features including user authentication, money transfer, transaction history, QR code generation, wallet management, and system monitoring. The implementation follows software engineering best practices and demonstrates practical application of theoretical concepts.')
    
    doc.add_page_break()
    
    # Acknowledgement
    ack_para = doc.add_paragraph()
    ack_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    ack_run = ack_para.add_run('Acknowledgement')
    ack_run.bold = True
    ack_run.font.size = Pt(14)
    
    doc.add_paragraph()
    doc.add_paragraph('I would like to express my sincere gratitude to my guide [Guide Name] for their valuable guidance, support, and encouragement throughout this project. Their expertise and insights have been instrumental in shaping this project.')
    
    doc.add_paragraph()
    doc.add_paragraph('I am grateful to [Institution Name] for providing the necessary infrastructure and learning environment. I would also like to thank my classmates and friends for their support and valuable discussions during the development of this project.')
    
    doc.add_paragraph()
    doc.add_paragraph('Finally, I thank my family for their unwavering support and motivation throughout my academic journey.')
    
    doc.add_page_break()
    
    # Abstract
    abs_para = doc.add_paragraph()
    abs_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    abs_run = abs_para.add_run('Abstract')
    abs_run.bold = True
    abs_run.font.size = Pt(14)
    
    doc.add_paragraph()
    doc.add_paragraph('The Smart UPI System is a comprehensive Java-based payment application that simulates the functionality of real-world UPI (Unified Payments Interface) systems. This project addresses the growing need for digital payment solutions by providing a secure, user-friendly platform for money transfers, transaction management, and financial monitoring.')
    
    doc.add_paragraph()
    doc.add_paragraph('The system is built using Java 15 with JavaFX 17 for the modern graphical interface, SQLite for data persistence with HikariCP connection pooling, and follows MVC architecture patterns. Key features include user registration and authentication, send/receive money functionality, QR code generation, wallet management for payment cards, comprehensive transaction history, and real-time system monitoring dashboard.')
    
    doc.add_paragraph()
    doc.add_paragraph('The project demonstrates practical implementation of software engineering concepts including object-oriented programming, database design, GUI development, and system architecture. It provides a complete solution that can serve as a foundation for understanding digital payment systems and modern application development practices.')
    
    doc.add_page_break()
    
    # 1. Project Overview
    heading1 = doc.add_heading('1. Project Overview', level=1)
    heading1.alignment = WD_ALIGN_PARAGRAPH.LEFT
    
    doc.add_paragraph('Introduction to the domain')
    doc.add_paragraph('The Unified Payments Interface (UPI) has revolutionized digital payments in India and other countries. It provides a real-time payment system that allows users to transfer money instantly between bank accounts using mobile devices. UPI has become the preferred method for digital transactions due to its simplicity, security, and convenience.')
    
    doc.add_paragraph()
    doc.add_paragraph('Background of the project')
    doc.add_paragraph('This project aims to create a functional UPI payment system that demonstrates the core features and workflows of real-world payment applications. The Smart UPI System provides a complete ecosystem for digital payments, including user management, transaction processing, and financial monitoring.')
    
    doc.add_paragraph()
    doc.add_paragraph('Purpose and significance')
    doc.add_paragraph('The purpose of this project is to:')
    doc.add_paragraph('   - Demonstrate practical understanding of Java programming and GUI development')
    doc.add_paragraph('   - Implement a complete payment system with real-world features')
    doc.add_paragraph('   - Provide a learning platform for understanding digital payment architectures')
    doc.add_paragraph('   - Showcase software engineering best practices and design patterns')
    
    doc.add_page_break()
    
    # 2. Problem Statement
    heading2 = doc.add_heading('2. Problem Statement', level=1)
    
    heading2_1 = doc.add_heading('2.1 Business Problem', level=2)
    doc.add_paragraph('Real-world issue the organization/user faces')
    doc.add_paragraph('In today\'s digital economy, there is a growing need for secure, efficient, and user-friendly payment systems. Traditional banking methods are often slow and inconvenient, while existing digital payment solutions may have complex interfaces or lack comprehensive features.')
    
    doc.add_paragraph()
    doc.add_paragraph('Impact on operations, cost, security, or efficiency')
    doc.add_paragraph('   - Traditional payment methods are time-consuming and inefficient')
    doc.add_paragraph('   - Lack of integrated wallet management features')
    doc.add_paragraph('   - Limited transaction history and monitoring capabilities')
    doc.add_paragraph('   - Security concerns with digital payments')
    doc.add_paragraph('   - Need for real-time transaction processing and monitoring')
    
    heading2_2 = doc.add_heading('2.2 Technical Problem', level=2)
    doc.add_paragraph('Technical gaps or limitations')
    doc.add_paragraph('   - Need for a robust database architecture to handle transactions')
    doc.add_paragraph('   - Requirement for secure user authentication and authorization')
    doc.add_paragraph('   - Need for responsive and intuitive user interface')
    doc.add_paragraph('   - Implementation of real-time system monitoring and performance tracking')
    
    doc.add_paragraph()
    doc.add_paragraph('Existing system drawbacks')
    doc.add_paragraph('   - Many educational projects lack comprehensive feature sets')
    doc.add_paragraph('   - Limited integration between different system components')
    doc.add_paragraph('   - Poor user experience and interface design')
    doc.add_paragraph('   - Lack of proper error handling and validation')
    
    doc.add_page_break()
    
    # 3. Scope
    heading3 = doc.add_heading('3. Scope', level=1)
    
    doc.add_paragraph('What is included in the project:')
    doc.add_paragraph('   - Complete user registration and authentication system')
    doc.add_paragraph('   - Money transfer functionality with PIN validation')
    doc.add_paragraph('   - QR code generation for receiving payments')
    doc.add_paragraph('   - Comprehensive transaction history and filtering')
    doc.add_paragraph('   - Wallet management for payment cards')
    doc.add_paragraph('   - Real-time system monitoring dashboard')
    doc.add_paragraph('   - User profile management')
    doc.add_paragraph('   - Database persistence with proper data modeling')
    
    doc.add_paragraph()
    doc.add_paragraph('What is excluded (limitations/boundaries):')
    doc.add_paragraph('   - Real bank integration (simulated for educational purposes)')
    doc.add_paragraph('   - Actual QR code scanning with camera')
    doc.add_paragraph('   - Biometric authentication')
    doc.add_paragraph('   - Multi-language support')
    doc.add_paragraph('   - Real-time notifications')
    doc.add_paragraph('   - Integration with external payment APIs')
    
    doc.add_page_break()
    
    # 4. Objectives
    heading4 = doc.add_heading('4. Objectives', level=1)
    
    doc.add_paragraph('Primary objective:')
    doc.add_paragraph('   - To develop a complete, functional UPI payment system that demonstrates modern software development practices and provides a comprehensive learning experience in digital payment technologies.')
    
    doc.add_paragraph()
    doc.add_paragraph('Secondary objectives:')
    doc.add_paragraph('   - Implement secure user authentication and authorization mechanisms')
    doc.add_paragraph('   - Create an intuitive and responsive user interface using JavaFX')
    doc.add_paragraph('   - Design and implement a robust database schema for transaction management')
    doc.add_paragraph('   - Develop real-time system monitoring and performance tracking')
    doc.add_paragraph('   - Implement proper error handling and validation throughout the system')
    doc.add_paragraph('   - Follow software engineering best practices and design patterns')
    
    doc.add_paragraph()
    doc.add_paragraph('Measurable goals:')
    doc.add_paragraph('   - Support user registration and authentication with 100% success rate')
    doc.add_paragraph('   - Process transactions with sub-second response time')
    doc.add_paragraph('   - Maintain transaction data integrity with proper validation')
    doc.add_paragraph('   - Provide comprehensive monitoring with real-time metrics')
    doc.add_paragraph('   - Achieve 95%+ code coverage in critical components')
    
    doc.add_page_break()
    
    # 5. System Architecture & Tools Used
    heading5 = doc.add_heading('5. System Architecture & Tools Used', level=1)
    
    heading5_1 = doc.add_heading('5.1 System Architecture', level=2)
    doc.add_paragraph('The Smart UPI System follows a layered architecture pattern with clear separation of concerns:')
    doc.add_paragraph()
    doc.add_paragraph('Presentation Layer (JavaFX):')
    doc.add_paragraph('   - Main application entry point and login screen')
    doc.add_paragraph('   - Dashboard with quick access to all features')
    doc.add_paragraph('   - Individual screens for each major functionality')
    doc.add_paragraph('   - Responsive UI components with modern styling')
    
    doc.add_paragraph()
    doc.add_paragraph('Business Logic Layer (Services):')
    doc.add_paragraph('   - UserService: User management and authentication')
    doc.add_paragraph('   - PaymentService: Transaction processing and validation')
    doc.add_paragraph('   - MonitoringService: System performance tracking')
    
    doc.add_paragraph()
    doc.add_paragraph('Data Access Layer (Repositories):')
    doc.add_paragraph('   - UserRepository: User data operations')
    doc.add_paragraph('   - TransactionRepository: Transaction data operations')
    doc.add_paragraph('   - WalletRepository: Payment card data operations')
    
    doc.add_paragraph()
    doc.add_paragraph('Database Layer (SQLite):')
    doc.add_paragraph('   - Persistent storage for user data')
    doc.add_paragraph('   - Transaction history and records')
    doc.add_paragraph('   - Wallet card information')
    doc.add_paragraph('   - Performance monitoring logs')
    
    heading5_2 = doc.add_heading('5.2 Tools & Technologies', level=2)
    
    # Create a table for technologies
    tech_table = doc.add_table(rows=0, cols=2)
    tech_table.style = 'Table Grid'
    
    technologies = [
        ('Java 15', 'Core programming language with modern features'),
        ('JavaFX 17', 'Modern GUI framework for desktop applications'),
        ('SQLite', 'Lightweight database for data persistence'),
        ('HikariCP', 'High-performance database connection pooling'),
        ('Maven', 'Build automation and dependency management'),
        ('ZXing', 'QR code generation library'),
        ('Jackson', 'JSON processing and serialization'),
        ('SLF4J', 'Logging framework for application monitoring'),
        ('JUnit 5', 'Unit testing framework'),
        ('MVC Pattern', 'Model-View-Controller architectural pattern')
    ]
    
    for tech, desc in technologies:
        row_cells = tech_table.add_row().cells
        row_cells[0].text = tech
        row_cells[1].text = desc
    
    doc.add_page_break()
    
    # 6. Project Work Distribution
    heading6 = doc.add_heading('6. Project Work Distribution', level=1)
    
    doc.add_paragraph('This project was developed as an individual effort with the following work distribution:')
    doc.add_paragraph()
    
    work_table = doc.add_table(rows=0, cols=2)
    work_table.style = 'Table Grid'
    
    work_items = [
        ('System Design & Architecture', 'Complete system design and component architecture'),
        ('Database Design', 'Schema design, table creation, and data modeling'),
        ('Frontend Development', 'JavaFX UI components, screens, and user experience'),
        ('Backend Development', 'Service layer, business logic, and data processing'),
        ('Integration & Testing', 'Component integration and comprehensive testing'),
        ('Documentation', 'Technical documentation and user guides')
    ]
    
    for component, responsibility in work_items:
        row_cells = work_table.add_row().cells
        row_cells[0].text = component
        row_cells[1].text = responsibility
    
    doc.add_page_break()
    
    # 7. Explanation of Project Modules
    heading7 = doc.add_heading('7. Explanation of Project Modules', level=1)
    
    # Module 1: User Management
    heading7_1 = doc.add_heading('Module 1: User Management', level=2)
    doc.add_paragraph('Description')
    doc.add_paragraph('The User Management module handles all user-related operations including registration, authentication, and profile management. It ensures secure access to the system and maintains user data integrity.')
    
    doc.add_paragraph()
    doc.add_paragraph('Functionality')
    doc.add_paragraph('   - User registration with KYC details (PAN, Aadhaar, bank information)')
    doc.add_paragraph('   - UPI ID generation with unique identifiers')
    doc.add_paragraph('   - Secure authentication with 4-digit PIN validation')
    doc.add_paragraph('   - Profile management and information updates')
    doc.add_paragraph('   - Login tracking and session management')
    
    doc.add_paragraph()
    doc.add_paragraph('Inputs/Outputs')
    doc.add_paragraph('   - Input: User details (name, phone, email, PIN, bank info)')
    doc.add_paragraph('   - Output: User authentication status, profile information, UPI ID')
    
    # Module 2: Payment System
    heading7_2 = doc.add_heading('Module 2: Payment System', level=2)
    doc.add_paragraph('Description')
    doc.add_paragraph('The Payment System module is the core of the UPI application, handling all money transfer operations, transaction processing, and payment validation.')
    
    doc.add_paragraph()
    doc.add_paragraph('Functionality')
    doc.add_paragraph('   - Send money to other UPI IDs with PIN verification')
    doc.add_paragraph('   - Receive money through QR codes and payment requests')
    doc.add_paragraph('   - Real-time balance updates and validation')
    doc.add_paragraph('   - Transaction fee calculation and processing')
    doc.add_paragraph('   - Payment status tracking and confirmation')
    
    doc.add_paragraph()
    doc.add_paragraph('Inputs/Outputs')
    doc.add_paragraph('   - Input: Recipient UPI ID, amount, PIN, remarks')
    doc.add_paragraph('   - Output: Transaction status, updated balance, transaction ID')
    
    # Module 3: Transaction Management
    heading7_3 = doc.add_heading('Module 3: Transaction Management', level=2)
    doc.add_paragraph('Description')
    doc.add_paragraph('This module manages all transaction records, providing comprehensive history tracking, filtering capabilities, and transaction analytics.')
    
    doc.add_paragraph()
    doc.add_paragraph('Functionality')
    doc.add_paragraph('   - Complete transaction history with detailed information')
    doc.add_paragraph('   - Transaction filtering by type, date, and amount')
    doc.add_paragraph('   - Transaction status tracking and updates')
    doc.add_paragraph('   - Transaction search and retrieval')
    doc.add_paragraph('   - Export capabilities for transaction records')
    
    doc.add_paragraph()
    doc.add_paragraph('Inputs/Outputs')
    doc.add_paragraph('   - Input: User UPI ID, filter criteria')
    doc.add_paragraph('   - Output: Transaction list, filtered results, transaction details')
    
    # Module 4: Wallet Management
    heading7_4 = doc.add_heading('Module 4: Wallet Management', level=2)
    doc.add_paragraph('Description')
    doc.add_paragraph('The Wallet Management module handles payment card storage, management, and security features for multiple payment methods.')
    
    doc.add_paragraph()
    doc.add_paragraph('Functionality')
    doc.add_paragraph('   - Add new payment cards with validation')
    doc.add_paragraph('   - Edit existing card information')
    doc.add_paragraph('   - View stored cards with security masking')
    doc.add_paragraph('   - Delete cards with confirmation')
    doc.add_paragraph('   - Set default payment methods')
    doc.add_paragraph('   - Card expiry validation and alerts')
    
    doc.add_paragraph()
    doc.add_paragraph('Inputs/Outputs')
    doc.add_paragraph('   - Input: Card details (number, holder, expiry, CVV, bank)')
    doc.add_paragraph('   - Output: Card list, masked card information, operation status')
    
    # Module 5: System Monitoring
    heading7_5 = doc.add_heading('Module 5: System Monitoring', level=2)
    doc.add_paragraph('Description')
    doc.add_paragraph('The System Monitoring module provides real-time insights into system performance, transaction metrics, and operational health.')
    
    doc.add_paragraph()
    doc.add_paragraph('Functionality')
    doc.add_paragraph('   - Real-time system metrics display')
    doc.add_paragraph('   - Transaction rate monitoring')
    doc.add_paragraph('   - Performance analytics and reporting')
    doc.add_paragraph('   - Error tracking and logging')
    doc.add_paragraph('   - Resource utilization monitoring')
    doc.add_paragraph('   - System health indicators')
    
    doc.add_paragraph()
    doc.add_paragraph('Inputs/Outputs')
    doc.add_paragraph('   - Input: System performance data, transaction logs')
    doc.add_paragraph('   - Output: Performance metrics, dashboard visualizations, health status')
    
    doc.add_page_break()
    
    # 8. Business Use Cases
    heading8 = doc.add_heading('8. Business Use Cases', level=1)
    
    doc.add_paragraph('How the project solves real-world business problems:')
    
    heading8_1 = doc.add_heading('Use Case 1: Small Business Payments', level=2)
    doc.add_paragraph('Scenario: A small business owner needs to receive payments from customers quickly and efficiently.')
    doc.add_paragraph('Solution: The Smart UPI System allows businesses to generate QR codes for instant payments, track all transactions in real-time, and maintain comprehensive payment records for accounting purposes.')
    
    heading8_2 = doc.add_heading('Use Case 2: Peer-to-Peer Transfers', level=2)
    doc.add_paragraph('Scenario: Friends and family members need to split bills and transfer money for shared expenses.')
    doc.add_paragraph('Solution: Users can instantly send money using UPI IDs, add remarks for transaction context, and maintain a complete history of all peer-to-peer transactions.')
    
    heading8_3 = doc.add_heading('Use Case 3: Financial Management', level=2)
    doc.add_paragraph('Scenario: Individuals need to track their spending and manage multiple payment methods.')
    doc.add_paragraph('Solution: The system provides transaction history with filtering capabilities, wallet management for multiple cards, and balance tracking for better financial management.')
    
    doc.add_page_break()
    
    # 9. Application Use Cases
    heading9 = doc.add_heading('9. Application Use Cases', level=1)
    
    heading9_1 = doc.add_heading('Use Case 1: User Registration', level=2)
    doc.add_paragraph('Actors: New User, System')
    doc.add_paragraph('Workflow:')
    doc.add_paragraph('   1. User opens the application and clicks "Register"')
    doc.add_paragraph('   2. User fills in personal details and creates a 4-digit PIN')
    doc.add_paragraph('   3. System validates the input and generates a unique UPI ID')
    doc.add_paragraph('   4. User account is created and stored in the database')
    doc.add_paragraph('   5. User can now log in with their UPI ID and PIN')
    doc.add_paragraph('Expected outcome: Successful user registration with unique UPI ID')
    
    heading9_2 = doc.add_heading('Use Case 2: Money Transfer', level=2)
    doc.add_paragraph('Actors: Sender, Receiver, System')
    doc.add_paragraph('Workflow:')
    doc.add_paragraph('   1. Sender logs in and navigates to "Send Money" screen')
    doc.add_paragraph('   2. Sender enters recipient\'s UPI ID and amount')
    doc.add_paragraph('   3. Sender adds optional remark and confirms with PIN')
    doc.add_paragraph('   4. System validates balance and processes the transaction')
    doc.add_paragraph('   5. Both sender and receiver balances are updated')
    doc.add_paragraph('   6. Transaction is recorded in both users\' history')
    doc.add_paragraph('Expected outcome: Successful money transfer with transaction confirmation')
    
    doc.add_page_break()
    
    # 10. Future Scope
    heading10 = doc.add_heading('10. Future Scope', level=1)
    
    doc.add_paragraph('Enhancements:')
    doc.add_paragraph('   - Real bank API integration for live transactions')
    doc.add_paragraph('   - Biometric authentication (fingerprint, face recognition)')
    doc.add_paragraph('   - Multi-language support for regional languages')
    doc.add_paragraph('   - Advanced security features (2FA, device binding)')
    doc.add_paragraph('   - Payment scheduling and recurring payments')
    doc.add_paragraph('   - Split bills and group payment features')
    
    doc.add_paragraph()
    doc.add_paragraph('Scalability options:')
    doc.add_paragraph('   - Cloud deployment for better accessibility')
    doc.add_paragraph('   - Microservices architecture for better scalability')
    doc.add_paragraph('   - Load balancing and caching mechanisms')
    doc.add_paragraph('   - Distributed database architecture')
    
    doc.add_paragraph()
    doc.add_paragraph('Integration possibilities:')
    doc.add_paragraph('   - Integration with popular banking apps')
    doc.add_paragraph('   - E-commerce platform payment gateway integration')
    doc.add_paragraph('   - Government payment systems integration')
    doc.add_paragraph('   - Third-party wallet services integration')
    
    doc.add_paragraph()
    doc.add_paragraph('AI/Automation improvements:')
    doc.add_paragraph('   - Fraud detection using machine learning')
    doc.add_paragraph('   - Predictive analytics for spending patterns')
    doc.add_paragraph('   - Automated customer support with chatbots')
    doc.add_paragraph('   - Intelligent transaction categorization')
    
    doc.add_page_break()
    
    # 11. Challenges Faced
    heading11 = doc.add_heading('11. Challenges Faced', level=1)
    
    doc.add_paragraph('Technical challenges:')
    doc.add_paragraph('   - Implementing secure PIN validation and encryption')
    doc.add_paragraph('   - Designing responsive UI components with JavaFX')
    doc.add_paragraph('   - Database connection management and performance optimization')
    doc.add_paragraph('   - Real-time transaction processing and consistency')
    doc.add_paragraph('   - QR code generation and integration')
    
    doc.add_paragraph()
    doc.add_paragraph('How they were resolved:')
    doc.add_paragraph('   - Used HikariCP for efficient database connection pooling')
    doc.add_paragraph('   - Implemented proper MVC architecture for better code organization')
    doc.add_paragraph('   - Added comprehensive error handling and validation')
    doc.add_paragraph('   - Used established libraries like ZXing for QR code generation')
    doc.add_paragraph('   - Implemented proper logging and monitoring for debugging')
    
    doc.add_page_break()
    
    # 12. Outcome
    heading12 = doc.add_heading('12. Outcome', level=1)
    
    doc.add_paragraph('Results achieved:')
    doc.add_paragraph('   - Complete functional UPI payment system with all major features')
    doc.add_paragraph('   - Secure user authentication and transaction processing')
    doc.add_paragraph('   - Intuitive user interface with modern design')
    doc.add_paragraph('   - Comprehensive transaction management and history')
    doc.add_paragraph('   - Real-time system monitoring and performance tracking')
    doc.add_paragraph('   - Robust database architecture with proper data modeling')
    
    doc.add_paragraph()
    doc.add_paragraph('Performance improvements:')
    doc.add_paragraph('   - Sub-second transaction processing time')
    doc.add_paragraph('   - Efficient database operations with connection pooling')
    doc.add_paragraph('   - Responsive UI with minimal loading times')
    doc.add_paragraph('   - Proper memory management and resource optimization')
    
    doc.add_paragraph()
    doc.add_paragraph('Metrics:')
    doc.add_paragraph('   - 15+ Java classes implementing complete system functionality')
    doc.add_paragraph('   - 4 database tables with proper relationships and constraints')
    doc.add_paragraph('   - 7 major UI screens with comprehensive functionality')
    doc.add_paragraph('   - Support for unlimited users and transactions')
    
    doc.add_page_break()
    
    # 13. Conclusion
    heading13 = doc.add_heading('13. Conclusion', level=1)
    
    doc.add_paragraph('Summary of the project')
    doc.add_paragraph('The Smart UPI System successfully demonstrates a complete implementation of a digital payment platform using modern Java technologies. The project encompasses all essential features of a UPI system including user management, secure transactions, wallet management, and system monitoring. The implementation follows software engineering best practices and provides a solid foundation for understanding digital payment architectures.')
    
    doc.add_paragraph()
    doc.add_paragraph('Learning outcomes')
    doc.add_paragraph('   - Comprehensive understanding of Java programming and JavaFX development')
    doc.add_paragraph('   - Practical experience with database design and management')
    doc.add_paragraph('   - Implementation of software design patterns and architectural principles')
    doc.add_paragraph('   - Understanding of security considerations in financial applications')
    doc.add_paragraph('   - Experience with modern development tools and frameworks')
    
    doc.add_paragraph()
    doc.add_paragraph('Final impact')
    doc.add_paragraph('This project provides a valuable educational resource for understanding digital payment systems and modern application development. It demonstrates practical implementation of theoretical concepts and serves as a foundation for future enhancements and real-world applications. The successful completion of this project showcases the ability to design, develop, and deploy complex software systems.')
    
    doc.add_page_break()
    
    # 14. References
    heading14 = doc.add_heading('14. References', level=1)
    
    references = [
        'Oracle Java Documentation - https://docs.oracle.com/javase/',
        'JavaFX 17 Documentation - https://openjfx.io/',
        'SQLite Documentation - https://www.sqlite.org/docs.html',
        'HikariCP Connection Pooling - https://github.com/brettwooldridge/HikariCP',
        'ZXing QR Code Library - https://github.com/zxing/zxing',
        'Maven Project Management - https://maven.apache.org/',
        'Unified Payments Interface (UPI) - NPCI Documentation',
        'Design Patterns: Elements of Reusable Object-Oriented Software - Gang of Four',
        'Effective Java - Joshua Bloch',
        'Clean Architecture - Robert C. Martin'
    ]
    
    for ref in references:
        doc.add_paragraph(ref)
    
    # Save the document
    doc.save('Smart_UPI_System_Project_Report.docx')
    print("Project report generated successfully!")

if __name__ == "__main__":
    create_project_report()
